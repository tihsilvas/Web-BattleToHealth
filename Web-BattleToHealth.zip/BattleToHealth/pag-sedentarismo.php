<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Segurança da Informação</title>
    <link rel="stylesheet" type="text/css" href="css/anima-surgi.css">
    <link rel="stylesheet" type="text/css" href="css/formato.css">
    <link rel="stylesheet" type="text/css" href="css/paginas-info.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
</head>
<body>
    <header>
        <?php include_once("includes/header.php"); ?>
    </header>
    <div class="container anSurgimento">
        <div class="logo-info">
            <img src="img/logo.jpg" alt="Battle to Health">
        </div>
        <h1>Consequências de uma Vida Sedentária</h1>
        <p class="p-titulo">Introdução e Conceitos:</p>
        <p>O sedentarismo se caracteriza pela falta de atividades físicas em pessoas de qualquer faixa etária. Entretanto, engana-se quem acredita que isso vale apenas para aquelas que não fazem nenhum tipo de exercício.
        Na verdade, também se caracteriza como sedentarismo a redução da prática de exercícios. Assim, uma pessoa pode ser sedentária, mesmo praticando alguma atividade. Isso ocorre quando ela não é feita de forma regular 
        ou é insuficiente para atender às necessidades do organismo.</p>
        </p>
        
        <p class="p-titulo">O Brasil é um país muito sedentário?</p>
        <p>Um estudo da Organização Mundial da Saúde (OMS) que durou 16 anos revelou que a América Latina é a região com o maior número de pessoas sedentárias no mundo. No Brasil, em particular, a situação é preocupante, com 47% da população vivendo uma vida sedentária, de acordo com o estudo. Essa tendência continua até hoje. Uma pesquisa recente do Instituto Brasileiro de Geografia e Estatística (IBGE) realizada em 2020 mostrou que quase metade dos brasileiros com mais de 18 anos não pratica atividade física suficiente. O problema é mais acentuado entre as pessoas com mais de 60 anos, com 59,7% delas sendo sedentárias.
        Além disso, a pesquisa do IBGE revelou que mais de 20 milhões de brasileiros usam produtos relacionados ao tabaco, e 26,4% da população adulta consome bebidas alcoólicas com frequência. A pandemia agravou essa situação, com 62% das pessoas pesquisadas em um estudo realizado pela Fiocruz e UFMG admitindo que pararam de praticar atividades físicas durante o período de isolamento social, passando mais tempo assistindo TV ou usando o computador. Um estudo adicional conduzido por pesquisadores da USP e UFPel, com base em dados da OMS de 54 países, concluiu que aproximadamente 4% das mortes em todo o mundo poderiam ser evitadas se as pessoas adotassem um estilo de vida menos sedentário. Portanto, a inatividade física representa um sério problema de saúde global que precisa ser abordado.
        </p>
        
        <div class="representa-image">
            <img src="img/sedentarismo.jpg">
            <p>Comece a se exercitar o mais rápido possível.</p>
        </div>

        <p class="p-titulo">Como reconhecer os indícios de uma vida sedentária:
            <li class="li-info">Cansaço intenso sem aparente razão;</li>
            <li class="li-info">Redução da força muscular;</li>
            <li class="li-info">Dores nas articulações;</li>
            <li class="li-info">Aumento no acúmulo de gordura no corpo (sobrepeso ou obesidade);</li>
            <li class="li-info">Evolução para a condição de sobrepeso;</li>
            <li class="li-info">Tendência a apresentar ronco e apneia do sono.</li>
        <br>

        <p class="p-titulo">Quais são os desdobramentos associados ao comportamento sedentário?</p>
        <p>
        A primeira vista, ficar parado pode ser mais atrativo do que praticar exercícios físicos. Porém, o corpo precisa de movimento na quantidade certa e, quando ele não recebe esse estímulo, as consequências são amplas.
        Há impactos na saúde física e na saúde mental. Como exemplo, tem-se a ligação de comportamentos sedentários com sintomas de depressão e de baixa autoestima.
        As consequências afetam a qualidade de vida. A seguir, você verá com mais detalhes as principais consequências que o sedentarismo provoca.
        </p>

        <p class="p-titulo">Doenças mentais</p>
        <p>
        Transtornos de ansiedade, depressão e Síndrome de Burnout são exemplos de doenças mentais que podem ser evitadas com a prática de exercícios físicos.
        </p>

        <p class="p-titulo">Doenças cardiovasculares</p>
        <p>
        Quando ficamos parados, nosso corpo não precisa trabalhar em um ritmo acelerado. O coração não precisa realizar esforço para bombear o sangue, ficando preguiçoso. Quando é exigido um pouco mais dele, não consegue suprir as necessidades do organismo.
        O coração sedentário se esforça demais para nutrir o corpo durante uma caminhada intensa ou uma pequena corrida, por exemplo. Há prejuízos para o sistema vascular, porque as veias sofrem uma contração, já que o fluxo de sangue é leve.
        O sedentarismo também favorece o aumento do colesterol. Camadas de gordura se formam nas artérias, prejudicando o fluxo sanguíneo. O coração precisa fazer um esforço maior para bombear o sangue, e tudo isso resulta em complicações de saúde.
        </p>    

        <p class="p-titulo">Diabetes</p>
        <p>
        O açúcar que consumimos é utilizado pelo organismo para produzir energia. Quando não nos exercitamos, ela não precisa ser gerada. Então, a tendência é que o nutriente se acumule na corrente sanguínea, causando diabetes.
        Essa é uma doença silenciosa e preocupante. Porque afeta o organismo de um modo geral, aumentando a disposição para inflamações. Desencadeia problemas oculares, renais, vasculares, entre muitos outros.
        </p> 

        <p class="p-titulo">Obesidade</p>
        <p>
        O corpo tem uma tendência natural para acumular reservas de energia, a fim de recorrer a elas se for necessário. É por isso que uma pessoa sedentária, geralmente, tem um acúmulo de gordura, podendo ficar obesa. Portanto, uma condição de risco para diversas doenças. Por exemplo, as doenças cardíacas, vasculares, respiratórias, articulares, o diabetes e, até mesmo, o câncer.
        </p>    

        <p class="p-titulo">Atrofia muscular</p>
        <p>
        São os músculos que possibilitam que o corpo realize algum esforço, como correr ou carregar um peso. Quanto mais eles são trabalhados, maior será a sua tonicidade, pois se adéquam à carga.
        Uma das consequências do sedentarismo é a atrofia muscular. Afinal, se a musculatura não está sendo utilizada, o corpo entende que não há necessidade de manter o volume dela. Os tecidos ficam flácidos e menores.   
        </p>
        <p style="margin-bottom: -1%; margin-top: 5%">Dra. Marcela Carvalho Pires</p>
        <p style="margin-bottom: -5%;">CRM-RJ647223</p>
    </div>
    <footer>
        <?php include_once("includes/footer.php"); ?>
    </footer>
</body>
</html>
