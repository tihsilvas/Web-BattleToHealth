<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" >
    <link rel="stylesheet" type="text/css" href="css/formato.css">
    <link rel="stylesheet" type="text/css" href="css/anima-surgi.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
    <title>index</title>
    <style>
        .mobile-container, .mobile-container2 {
            width: 42%;
            height: auto;
            float: left;
            height: 100vh;
            color: white;
            font-family: Arial, Helvetica, sans-serif;
            font-weight: bold;
            user-select: none;
        }

        .mobile-container2 {
            width: 58%;
            background-image: url("img/papagaio.PNG");
            background-size: cover;
            background-position: 45%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .index-container2 {
            margin-top: 10vh;
            width: 100%;
            height: 100vh;
            font-family: Arial, Helvetica, sans-serif;
            background: linear-gradient(180deg, rgba(40,103,208,1) 0%, rgba(255,255,255,1) 120%);
        }

        .mobile-text1, .mobile-text2, .mobile-text3 {
            width: 80%;
            font-size: 9vh;
            height: 30vh;
            margin: 0% 0% 5% 10%;
        }

        .mobile-text3 {
            width: 40%;
            font-size: 2vh;
            height: 12vh;
            margin: 0% 0% 0% 10.5%;
            margin-bottom: 2%;
        }

        .mobile-text4, .mobile-text5 {
            width: 90%;
            font-size: 8vh;
            font-weight: 60;
            height: 12vh;
            margin: 26% 0% 0% 8%;
            text-align: left;
            margin-bottom: 5%;
        }
        .mobile-text5 {
            font-size: 2.7vh;
            font-weight: 60;
            margin: 12% 0% 0% 8%;
        }

        .mobile-text1 {
            margin: 10% 0% 5% 0%;
            font-size: 2.7vh;
            margin-left: 10.5%;
            height: 3vh;
        }

        .store-icons {
            width: 100%;
            height: 10vh;
            margin-top: 25vh;
        }

        .store-icons a {
            margin: 0vh 0vh 0vh 9vh;
            width: 28%;
            height: 85%;
            float: left;
        }

        .store-icons img {
            border: 3px solid black;
            border-radius: 10px;
            height: 100%;
        }

        .mobile-container2 img{
            border-radius: 35px;
            width: 50%;
            
        }

        .fonte-azul{
            color: #121C42;
        }
    </style>
</head>
<body>
    <header>
        <?php include_once("includes/header.php");?>
    </header>
    <main>
        <div class="index-container2">
            <div class="mobile-container">
                <div class="mobile-text1"><i class="fa fa-bullseye" aria-hidden="true"></i>Battle to Health Inc</div>
                <div class="mobile-text2">BAIXE O APP<br> APROVEITE AS<br> OFERTAS</div>
                <div class="mobile-text3">Melhore sua qualidade de vida com nosso app! Acesse os melhores serviços a qualquer hora, acompanhe e simplifique sua vida. Baixe agora!</div>
                <div class="store-icons">
                    <a href="https://play.google.com/store">
                        <img src="img/play-store.png" alt="Play Store">
                    </a>
                    <a href="https://www.apple.com/app-store/">
                        <img src="img/app-store.png" alt="App Store">
                    </a>
                </div>
            </div>
            <div class="mobile-container mobile-container2"></div>
        </div>
        <div style="background: none; background-color: white; margin-top: none" class="index-container2">   
            <div style="background: none; width: 45%;" class="mobile-container mobile-container2">
                <img src="img/cel1.PNG" alt="Celular 1">
            </div>
            <div style="width: 54%;" class="mobile-container">
                <div class="mobile-text4 fonte-azul">Acompanhe e Controle seu Consumo de Água</div>
                <div class="mobile-text5 fonte-azul">
                    Registre seu consumo diário de água facilmente e nunca esqueça de beber água ao longo do dia. Favorite metas diárias, acompanhe seu progresso, personalize metas, receba lembretes, e visualize seu histórico de consumo para ajustar suas metas conforme necessário.
                </div>
            </div>
        </div>
        <div style="background: none; background-color: rgb(247, 247, 247);" class="index-container2">   
            <div  style="width: 54%;" class="mobile-container">
                <div class="mobile-text4 fonte-azul">Controle e Monitore seu Treinamento Físico</div>
                <div class="mobile-text5 fonte-azul">
                    Registre atividades físicas facilmente, acompanhe treinos diários, favorite atividades, e monitore seu progresso. Personalize metas de fitness, receba lembretes e visualize seu histórico de atividades para ajustar suas metas conforme necessário.
                </div>
            </div>
            <div style="background: none; width: 45%;" class="mobile-container mobile-container2">
                <img src="img/cel2.PNG" alt="Celular 1">
            </div>
        </div>
    </main>
    <footer>
        <?php include_once("includes/footer.php");?>
    </footer>
</body>
</html>
