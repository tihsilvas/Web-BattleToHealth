<?php
require_once "conexao.php";
session_start();

if (isset($_GET['logout']) && $_GET['logout'] == 1) {
    unset($_SESSION['logado'], $_SESSION['username']);
    header('Location: index.php');
    exit();
}

$loginStatus = isset($_SESSION['logado']) && $_SESSION['logado'] === true;
$nomeUsuario = "";
$foto_usuario = "img/user.png";

if (empty($nomeUsuario) && $loginStatus) {
    $email = $_SESSION['email'] ?? '';

    $conn = mysqli_connect($servidor, $usuario, $senha, $banco, $porta);
    $query = "SELECT nome_usuario, foto_usuario FROM tb_usuario WHERE email_usuario = '$email'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nomeUsuario = $row['nome_usuario'];
        $_SESSION['username'] = $nomeUsuario;
        $foto_usuario = $row['foto_usuario'];
        
        if(empty($foto_usuario)) {
            $foto_usuario = "img/user.png";
        }
    }
    $sql = "SELECT bio_usuario FROM tb_usuario WHERE email_usuario = '$email'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $bio_usuario = $row['bio_usuario'];
    } else {
        $bio_usuario = "Nenhuma biografia encontrada.";
    }
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="pt">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Header com PHP</title>
    <link rel="stylesheet" type="text/css" href="css/formato.css">
    <link rel="stylesheet" type="text/css" href="css/header.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
    <style>
        .profile-pic, .user-img {
            width: 4.2vh;
            height: 4.4vh;
            border-radius: 50%;
            cursor: pointer;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <a href="index.php">
                <img src="IMG/logo.jpg" alt="Logo">
            </a>
        </div>
        <nav class="nav">
            <ul>
            <ul class="logo-text">
                <li class="logo-text1"><a href="index.php" style="color: #2174a1;">Battle to Health</a></li>
            </ul>
            <li><a href="pag-sobre.php">Sobre</a></li>
            <li><a href="pag-politica.php">Termos e Política</a></li>
            <li class="servicos">
                <span class="servicos-item">
                    <img id="seta-img" src="img/seta.png" class="seta-img">    
                    Serviços
                    <div class="submenu">
                    <a href="pag-atividade-fisica.php">Atividades</a>
                        <a href="calc_alimenticia/calculadora.php">Calculadora</a>
                        <a href="pag-agua.php">Hidratação</a>
                        <a href="pag-mobile.php">Mobile</a>
                        <a href="pag-sedentarismo.php">Sedentarismo</a>
                        <a href="pag-sono.php">Sono</a>
                    </div>
                </span>
                </li>
                <div class="line-divider"></div>
                <?php if($loginStatus) { ?>
                    <li><a id="login-status" href="perfil.php"><?php echo $nomeUsuario; ?></a></li>
                    <a href="perfil.php"><img src="<?php echo $foto_usuario; ?>" alt="Foto de Perfil" class="profile-pic"></a>
                <?php } else { ?>
                    <li><a id="login-status" href="login.php">Entrar</a></li>
                    <a href="login.php"><img src="<?php echo $foto_usuario; ?>" class="user-img" ></a>
                <?php } ?>
            </ul>
        </nav>
    </header>
</body>
</html>
