<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <link rel="stylesheet" type="text/css" href="css/formato.css">
    <link rel="stylesheet" type="text/css" href="css/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
</head>
<body>
    <footer>
        <div class="dados-footer">
            <p class="p-footer" style="user-select: none;">&copy; 2024 Battle to Health. Todos os direitos reservados.</p>
        </div>
        <div class="redes-sociais">
            <a href="mailto:battletohealth@gmail.com" target="_blank"><i class="fa fa-envelope"></i></a>
            <a href="https://www.google.com/maps/search/?api=1&query=Alameda+Nothmann,+598+-+Campos+Elíseos,+São+Paulo+-+SP,+01216-000" target="_blank"><i class="fas fa-map-marker-alt"></i></a>
            <!-- <a href="https://www.facebook.com/seu_facebook" target="_blank"><i class="fab fa-facebook"></i></a> -->
            <a href="https://www.instagram.com/battletohealth_/?igsh=MTRiYWFhdGJ3N2o2ZA%3D%3D&utm_source=qr" target="_blank"><i class="fab fa-instagram"></i></a>
        </div>
    </footer>
</body>
</html>
