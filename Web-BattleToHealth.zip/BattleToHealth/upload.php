<?php
require_once "includes/conexao.php";

session_start();
if (!isset($_SESSION['email'])) {
    echo "Erro: Nenhum email encontrado na sessão.";
    exit;
}

$email = $_SESSION['email'];

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['txt_foto'])) {
    // Upload da nova foto de perfil
    $upload_dir = "perfil/"; // Diretório onde deseja salvar as fotos
    $filename = uniqid() . '_' . $_FILES['txt_foto']['name'];
    $destination = $upload_dir . $filename;

    if(move_uploaded_file($_FILES['txt_foto']['tmp_name'], $destination)) {
        $query = "UPDATE tb_usuario SET foto_usuario = '$destination' WHERE email_usuario = '$email'";
        
        $sql = mysqli_query($conn, $query);
        if($sql) {
            header("Location: perfil.php");
            exit;
        } else {
            echo "Erro ao atualizar a foto de perfil: " . mysqli_error($conn);
            exit;
        }
    } else {
        echo "Erro ao fazer upload da foto.";
        exit;
    }
} else {
    header("Location: perfil.php");
    exit;
}
?>
