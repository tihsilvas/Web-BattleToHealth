<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");
    exit();
}
require_once __DIR__ . "/../includes/conexao.php";

$email = $_SESSION['email'];

include_once("consulta_grafico/consulta-atividade-fisica.php"); 
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gráfico de Atividade Física</title>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="../css/consumo.css">
    <link rel="stylesheet" type="text/css" href="../css/anima-surgi.css">
    <link rel="stylesheet" href="../css/voltar-icone.css">
    <link rel="stylesheet" href="../css/sucesso.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="icon" href="../img/battle.ico" type="image/x-icon">
    <style>
        h3 {
            color: #333;
        }
    </style>
</head>
<body class="anSurgimento">

<div class="alert" id="alertaSucesso">
    Registro de tempo de água realizado com sucesso!
</div>
<div class="alert" id="alertaErro">
    Erro ao registrar o conteúdo. Tente novamente.
</div>

<a href="../perfil.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
    <div class="container">
        <h1>Gráfico de Atividade Física</h1>
        <?php
            $tituloGrafico = $verTodoPeriodo ? $anoSelecionado : 'Atividade Física em ' . obterNomeMes($mesSelecionado);
            if (!$mesSelecionado && !$verTodoPeriodo) {
                $tituloGrafico = 'Atividade Física em '. $anoAtualBrasil;
            }
        ?>
        <h3 id="tituloGrafico"><?= $tituloGrafico ?></h3>
        <form class="form-data" method="post" action="registro_banco/upload-atividade.php">
            <h3>Registro de Dados</h3>
            <hr style="border-color: #ccc;">
            <div class="input-group">
                <label for="atividade-tipo">Atividade</label>
                <input type="text" id="atividade-tipo" name="atividade_tipo" min="0" max="24" step="0.01">
                <br>
                <label for="atividade-inicio">Inicio</label>
                <input type="time" id="atividade-inicio" name="atividade_inicio" min="00:00" max="23:59" value="<?= date('H:i') ?>">
                <br>
                <label for="atividade-final">Término</label>
                <input type="time" id="atividade-final" name="atividade_final" min="00:00" max="23:59" value="<?= date('H:i') ?>">
                <br>
                <label for="atividade-data">Data</label>
                <input type="date" id="atividade-data" name="atividade_data" min="1900-01-01" max="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>">
                <br>
            </div>
            <br>
            <button type="submit" style="margin-bottom: 1.5vh;">Registrar</button>
            <br>
            <button type="button" onclick="window.location.href='delete_banco/delete_view/delete-view-atividade.php'">Editar Dados</button>
        </form>
        <canvas id="graficoAtividadeFisica"></canvas>
        <form class="form-data form-c" method="GET">
            <h3>Consulta de Data</h3>
            <hr style="border-color: #ccc;">
            <div class="input-group">
                <label for="mes">Mês</label>
                <input type="number" id="mes" name="mes" min="1" max="12" value="<?= $mesSelecionado ?>">
                <br>
                <label for="ano">Ano</label>
                <input type="number" id="ano" name="ano" min="1900" max="<?= date('Y') ?>" value="<?= $anoSelecionado ?>">
            </div>
            <br>
            <button type="submit">Consultar Mês</button>
            <br>
            <button type="submit" name="ver_todos" value="true">Consultar Ano</button>
        </form>
    </div>
        <script>
            var ctx = document.getElementById('graficoAtividadeFisica').getContext('2d');
            var myChart;

            function exibirGrafico(tipoGrafico, labels, valores) {
                if (myChart) {
                    myChart.destroy();
                }

                myChart = new Chart(ctx, {
                    type: tipoGrafico,
                    data: {
                        labels: labels,
                        datasets: [{
                            label: tipoGrafico === 'line' ? 'Atividade Física por Dia' : 'Atividade Física por Mês',
                            data: valores,
                            backgroundColor: 'rgba(54, 162, 235, 0.2)',
                            borderColor: 'rgba(54, 162, 235, 1)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: {
                                    callback: function(value, index, values) {
                                        return value + ' horas';
                                    }
                                }
                            },
                            x: {
                                title: {
                                    display: true,
                                    text: tipoGrafico === 'line' ? 'Dias do Mês' : 'Mês'
                                }
                            }
                        },
                        plugins: {
                            tooltip: {
                                mode: 'index',
                                intersect: false
                            }
                        }
                    }
                });
            }
            exibirGrafico('<?= $tipoGrafico ?>', <?= json_encode($labels) ?>, <?= json_encode($valores) ?>);
        </script>
        <script src="../js/sucesso.js"></script>
    </div>
</body>
</html>