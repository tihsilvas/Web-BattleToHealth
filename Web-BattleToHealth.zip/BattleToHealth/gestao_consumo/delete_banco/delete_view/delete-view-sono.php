<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: ../../../login.php");
    exit();
}

require_once "../../../includes/conexao.php";

$mensagem = "";

$email = $_SESSION['email'];
$sql_id = "SELECT id_usuario FROM tb_usuario WHERE email_usuario = ?";
$stmt_id = $conn->prepare($sql_id);
$stmt_id->bind_param("s", $email);
$stmt_id->execute();
$result_id = $stmt_id->get_result();

if ($result_id->num_rows > 0) {
    $row = $result_id->fetch_assoc();
    $id_usuario = $row['id_usuario'];

    // Verificar se a data foi enviada via POST
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Processar a consulta do banco de dados com base na data especificada
        $data = $_POST['data'];

        // Consultar o banco de dados para obter os registros do usuário na data especificada
        $sql = "SELECT * FROM tb_sono WHERE id_usuario = ? AND data_sono = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("is", $id_usuario, $data);
        $stmt->execute();
        $resultado = $stmt->get_result();

        if ($resultado->num_rows > 0) {
            // Exibir os registros do usuário na data especificada
        } else {
            $mensagem = "Nenhum registro encontrado para esta data.";
        }
    } else {
        $resultado = null;
    }

    // Consultar todos os registros do usuário
    $sql_todos_registros = "SELECT * FROM tb_sono WHERE id_usuario = ?";
    $stmt_todos_registros = $conn->prepare($sql_todos_registros);
    $stmt_todos_registros->bind_param("i", $id_usuario);
    $stmt_todos_registros->execute();
    $resultado_todos_registros = $stmt_todos_registros->get_result();
} else {
    $mensagem = "Erro: Usuário não encontrado.";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apagar Dados de Sono Registrados</title>
    <link rel="stylesheet" href="../../../css/voltar-icone.css">
    <link rel="stylesheet" type="text/css" href="../../../css/anima-surgi.css">
    <link rel="stylesheet" type="text/css" href="../../../css/formato.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" type="text/css" href="../../../css/footer.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../../../css/sucesso.css">
    <link rel="stylesheet" href="../../../css/delete.css">
    <link rel="icon" href="../../../img/battle.ico" type="image/x-icon">
</head>
<body>
    <div class="inicio">
        <a href="../../tempo-sono.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
        <h1>Apagar Dados de Sono Registrados</h1>
    </div>

    <div class="alert" id="alertaSucesso">
        Registro de tempo de sono apagado com sucesso!
    </div>
    <div class="alert" id="alertaErro">
        Erro ao apagar o conteúdo.
    </div>

    <div class="container anSurgimento">
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="data">Escolha uma data para consultar:</label>
            <input type="date" id="data" name="data">
            <button type="submit">Consultar</button>
        </form>
        <?php if ($mensagem): ?>
            <p><?php echo $mensagem; ?></p>
        <?php endif; ?>
        <div class="registros">
            <?php
            if ($resultado && $resultado->num_rows > 0) {
                while ($row = $resultado->fetch_assoc()) {
                    echo "<div class='registro'>";
                    echo "<p><strong>Data:</strong> {$row['data_sono']}</p>";
                    echo "<p><strong>Tempo de Sono:</strong> {$row['temp_sono']} horas</p>";
                    echo "<p><strong>Horário de Dormir:</strong> {$row['hr_sono']}</p>";
                    echo "<a href='../delete_info/delete-info-sono.php?delete={$row['id_sono']}' class='apagar'>Apagar</a>";
                    echo "<a href='#' class='editar' onclick='openModal({$row['id_sono']}, \"{$row['data_sono']}\", {$row['temp_sono']}, \"{$row['hr_sono']}\")'>Editar</a>";
                    echo "</div>";
                }
            }
            ?>
        </div>
    </div>
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2 style="text-align: center; font-size: 3.2vh; margin-bottom: 2%;">Edição de Dados</h2>
            <form id="editRecordForm" method="post">
                <div class="form-group">
                    <label for="edit_data">Data:</label>
                    <input type="date" id="edit_data" name="edit_data" class="form-control" style="text-align: center;" readonly>
                </div>
                <div class="form-group">
                    <label for="edit_temp_sono">Tempo de Sono (horas):</label>
                    <input type="number" id="edit_temp_sono" name="edit_temp_sono" class="form-control" style="text-align: center;">
                </div>
                <div class="form-group">
                    <label for="edit_hr_sono">Horário de Dormir:</label>
                    <input type="time" id="edit_hr_sono" name="edit_hr_sono" class="form-control" style="text-align: center;">
                </div>
                <input type="hidden" id="id_sono" name="id_sono">
                <div class="button-group" style="text-align: center;">
                    <button type="button" class="btn-save" onclick="saveEdit()">Salvar</button>
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
    <script>
        function openModal(id, data, temp_sono, hr_sono) {
            document.getElementById("editModal").style.display = "block";
            document.getElementById("id_sono").value = id;
            document.getElementById("edit_data").value = data;
            document.getElementById("edit_temp_sono").value = temp_sono;
            document.getElementById("edit_hr_sono").value = hr_sono;
        }

        function closeModal() {
            document.getElementById("editModal").style.display = "none";
        }

        function saveEdit() {
            // Obter os valores dos campos do formulário
            var id_sono = document.getElementById("id_sono").value;
            var data = document.getElementById("edit_data").value;
            var temp_sono = document.getElementById("edit_temp_sono").value;
            var hr_sono = document.getElementById("edit_hr_sono").value;

            // Criar um objeto FormData para enviar os dados via AJAX
            var formData = new FormData();
            formData.append('id_sono', id_sono);
            formData.append('data', data);
            formData.append('temp_sono', temp_sono);
            formData.append('hr_sono', hr_sono);

            // Enviar os dados via AJAX
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    // Se a requisição for bem-sucedida, fechar o modal e recarregar a página
                    closeModal();
                    location.reload();
                }
            };
            xhr.open("POST", "../editar_info/editar-info-sono.php", true);
            xhr.send(formData);
        }
    </script>
    <footer> <?php include_once("../../../includes/footer.php");?></footer>
    <script src="../../../js/sucesso.js"></script>
</body>
</html>
