<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: ../../../login.php");
    exit();
}

require_once "../../../includes/conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_atividade = $_POST['id_atividade'];
    $data = $_POST['data'];
    $tipo_atividade = $_POST['tipo_atividade'];
    $temp_atividade = $_POST['temp_atividade'];

    $sql_update = "UPDATE tb_atividade_fisica SET data_atividade = ?, tipo_atividade = ?, temp_atividade = ? WHERE id_atividade = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("sssi", $data, $tipo_atividade, $temp_atividade, $id_atividade);
    if ($stmt_update->execute()) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
