<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: ../../../login.php");
    exit();
}

require_once "../../../includes/conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_sono = $_POST['id_sono'];
    $data = $_POST['data'];
    $temp_sono = $_POST['temp_sono'];
    $hr_sono = $_POST['hr_sono'];

    $sql_update = "UPDATE tb_sono SET data_sono = ?, temp_sono = ?, hr_sono = ? WHERE id_sono = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("sssi", $data, $temp_sono, $hr_sono, $id_sono);
    if ($stmt_update->execute()) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
