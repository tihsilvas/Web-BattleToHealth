<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: ../../../login.php");
    exit();
}

require_once "../../../includes/conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_alimentacao = $_POST['id_alimentacao'];
    $data = $_POST['data'];
    $hr_alimentacao = $_POST['hr_alimentacao'];
    $tipo_alimentacao = $_POST['tipo_alimentacao'];
    $calorias_alimentacao = $_POST['calorias_alimentacao'];

    $sql_update = "UPDATE tb_alimentacao SET data_alimentacao = ?, hr_alimentacao = ?, tipo_alimentacao = ?, calorias_alimentacao = ? WHERE id_alimentacao = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ssssi", $data, $hr_alimentacao, $tipo_alimentacao, $calorias_alimentacao, $id_alimentacao);
    if ($stmt_update->execute()) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
