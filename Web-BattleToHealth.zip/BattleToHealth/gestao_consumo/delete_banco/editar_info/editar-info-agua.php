<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: ../../../login.php");
    exit();
}

require_once "../../../includes/conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id_agua = $_POST['id_agua'];
    $data = $_POST['data'];
    $qnt_agua = $_POST['qnt_agua'];
    $hr_agua = $_POST['hr_agua'];

    $sql_update = "UPDATE tb_agua SET data_agua = ?, qnt_agua = ?, hr_agua = ? WHERE id_agua = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("sdsi", $data, $qnt_agua, $hr_agua, $id_agua);
    if ($stmt_update->execute()) {
        echo "success";
    } else {
        echo "error";
    }
}
?>
