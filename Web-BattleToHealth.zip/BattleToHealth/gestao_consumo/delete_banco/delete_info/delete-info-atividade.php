<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: ../../../login.php");
    exit();
}

require_once "../../../includes/conexao.php";

if (isset($_GET['delete'])) {
    $id_atividade = $_GET['delete'];

    // Preparar e executar a consulta de deleção
    $sql_delete = "DELETE FROM tb_atividade_fisica WHERE id_atividade = ?";
    $stmt_delete = $conn->prepare($sql_delete);
    $stmt_delete->bind_param("i", $id_atividade);

    if ($stmt_delete->execute()) {
        // Redirecionar de volta para a página anterior após a deleção com o parâmetro de sucesso
        header("Location: ../delete_view/delete-view-atividade.php?success=true");
        exit();
    } else {
        echo "Erro ao deletar o registro.";
    }
} else {
    echo "ID do registro não fornecido.";
}
?>
