<?php
function obterDadosAtividadeFisicaDia($conn, $email, $mesSelecionado, $anoSelecionado) {
    $sql = "SELECT data_atividade, SUM(temp_atividade) AS total 
            FROM tb_atividade_fisica 
            WHERE id_usuario = (SELECT id_usuario FROM tb_usuario WHERE email_usuario = ?)";

    $params = [$email];

    if ($mesSelecionado && $anoSelecionado) {
        $sql .= " AND MONTH(data_atividade) = ? AND YEAR(data_atividade) = ?";
        $params[] = $mesSelecionado;
        $params[] = $anoSelecionado;
    }

    $sql .= " GROUP BY data_atividade ORDER BY data_atividade";

    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt === false) {
        die("Erro na preparação da consulta: " . mysqli_error($conn));
    }

    $types = str_repeat('s', count($params));
    mysqli_stmt_bind_param($stmt, $types, ...$params);

    if (!mysqli_stmt_execute($stmt)) {
        die("Erro ao executar a consulta: " . mysqli_stmt_error($stmt));
    }

    $resultado = mysqli_stmt_get_result($stmt);

    $dados = [];
    while ($row = mysqli_fetch_assoc($resultado)) {
        $dados[$row['data_atividade']] = $row['total'];
    }

    mysqli_stmt_close($stmt);

    return $dados;
}

function obterDadosAtividadeFisicaMes($conn, $email) {
    $sql = "SELECT MONTH(data_atividade) AS mes, SUM(temp_atividade) AS total 
            FROM tb_atividade_fisica 
            WHERE id_usuario = (SELECT id_usuario FROM tb_usuario WHERE email_usuario = ?)
            GROUP BY mes ORDER BY mes";

    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt === false) {
        die("Erro na preparação da consulta: " . mysqli_error($conn));
    }

    mysqli_stmt_bind_param($stmt, "s", $email);

    if (!mysqli_stmt_execute($stmt)) {
        die("Erro ao executar a consulta: " . mysqli_stmt_error($stmt));
    }

    $resultado = mysqli_stmt_get_result($stmt);

    $dados = [];
    while ($row = mysqli_fetch_assoc($resultado)) {
        $mes = obterNomeMes($row['mes']);
        $dados[$mes] = $row['total'];
    }

    mysqli_stmt_close($stmt);

    $todosMeses = array_map('obterNomeMes', range(1, 12));
    $dadosPreenchidos = [];
    foreach ($todosMeses as $mes) {
        $dadosPreenchidos[$mes] = $dados[$mes] ?? 0;
    }

    return $dadosPreenchidos;
}

function obterNomeMes($numeroMes) {
    $nomesMeses = [
        1 => 'Janeiro',
        2 => 'Fevereiro',
        3 => 'Março',
        4 => 'Abril',
        5 => 'Maio',
        6 => 'Junho',
        7 => 'Julho',
        8 => 'Agosto',
        9 => 'Setembro',
        10 => 'Outubro',
        11 => 'Novembro',
        12 => 'Dezembro'
    ];
    $mes = (int)$numeroMes;
    if (isset($nomesMeses[$mes])) {
        return $nomesMeses[$mes];
    } else {
        return null;
    }
}

$mesSelecionado = isset($_GET['mes']) ? max(1, min(12, (int)$_GET['mes'])) : '';
$anoSelecionado = $_GET['ano'] ?? date('Y');

$verTodoPeriodo = isset($_GET['ver_todos']);

$anoAtualBrasil = date('Y');

$labels = [];
$valores = [];
$tipoGrafico = '';

if (!$verTodoPeriodo) {
    $dadosAtividadeFisicaDia = obterDadosAtividadeFisicaDia($conn, $email, $mesSelecionado, $anoSelecionado);

    $ultimoDia = date('t', strtotime($anoSelecionado . '-' . $mesSelecionado . '-01'));

    for ($dia = 1; $dia <= $ultimoDia; $dia++) {
        $data = sprintf('%04d-%02d-%02d', $anoSelecionado, $mesSelecionado, $dia);
        $labels[] = $dia;
        $valores[] = $dadosAtividadeFisicaDia[$data] ?? 0;
    }

    $tipoGrafico = 'line';
} else {
    $dadosAtividadeFisicaMes = obterDadosAtividadeFisicaMes($conn, $email);

    $labels = array_keys($dadosAtividadeFisicaMes);
    $valores = array_values($dadosAtividadeFisicaMes);

    $tipoGrafico = 'bar';
}

mysqli_close($conn);
?>