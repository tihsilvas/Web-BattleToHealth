<?php
session_start();

include "../../includes/conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["atividade_tipo"]) && !empty($_POST["atividade_data"]) && !empty($_POST["atividade_inicio"]) && !empty($_POST["atividade_final"])) {
        $tipo = $_POST["atividade_tipo"];
        $data = $_POST["atividade_data"];
        $inicio = $_POST["atividade_inicio"];
        $final = $_POST["atividade_final"];
        $email = $_SESSION['email'] ?? '';

        $sql_id = "SELECT id_usuario FROM tb_usuario WHERE email_usuario = ?";
        $stmt_id = $conn->prepare($sql_id);
        $stmt_id->bind_param("s", $email);
        $stmt_id->execute();
        $result_id = $stmt_id->get_result();

        if ($result_id->num_rows > 0) {
            $row_id = $result_id->fetch_assoc();
            $id_usuario = $row_id['id_usuario'];

            $inicio_obj = new DateTime($data . ' ' . $inicio);
            $final_obj = new DateTime($data . ' ' . $final);

            $intervalo = $inicio_obj->diff($final_obj);
            $tempo_atividade = $intervalo->format('%H.%i');

            $sql_insert = "INSERT INTO tb_atividade_fisica (id_usuario, tipo_atividade, data_atividade, temp_atividade) VALUES (?, ?, ?, ?)";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bind_param("isss", $id_usuario, $tipo, $data, $tempo_atividade);

            if ($stmt_insert->execute()) {
                header("Location: ../atividade-fisica.php?success=true");
                exit();
            } else {
                header("Location: ../atividade-fisica.php?error=true");
            }
        } else {
            header("Location: ../atividade-fisica.php?error=true");
        }
        $stmt_id->close();
    } else {
        header("Location: ../atividade-fisica.php?error=true");
    }
}
$conn->close();
?>
