<?php
session_start();

include "../../includes/conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["sono-inicio"]) && !empty($_POST["sono-final"]) && !empty($_POST["data_sono"])) {
        $inicio_sono = $_POST["sono-inicio"];
        $final_sono = $_POST["sono-final"];
        $data_sono = $_POST["data_sono"];
        $email = $_SESSION['email'] ?? '';

        // Consulta o ID do usuário com base no email
        $sql_id = "SELECT id_usuario FROM tb_usuario WHERE email_usuario = ?";
        $stmt_id = $conn->prepare($sql_id);
        $stmt_id->bind_param("s", $email);
        $stmt_id->execute();
        $result_id = $stmt_id->get_result();

        if ($result_id->num_rows > 0) {
            $row_id = $result_id->fetch_assoc();
            $id_usuario = $row_id['id_usuario'];

            // Converte as strings de tempo para objetos DateTime
            $inicio_sono_obj = new DateTime($data_sono . ' ' . $inicio_sono);
            $final_sono_obj = new DateTime($data_sono . ' ' . $final_sono);

            // Calcula a diferença de tempo como um intervalo
            $intervalo = $inicio_sono_obj->diff($final_sono_obj);

            // Converte a diferença de tempo para horas decimais
            $horas = $intervalo->h + ($intervalo->i / 60) + ($intervalo->s / 3600);

            // Insere os dados de sono na tabela tb_sono
            $sql_insert = "INSERT INTO tb_sono (id_usuario, temp_sono, data_sono, hr_sono) VALUES (?, ?, ?, ?)";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bind_param("idss", $id_usuario, $horas, $data_sono, $inicio_sono);

            if ($stmt_insert->execute()) {
                header("Location: ../tempo-sono.php?success=true");
                exit();
            } else {
                header("Location: ../tempo-sono.php?error=true");
            }
        } else {
            header("Location: ../tempo-sono.php?error=true");
        }
        $stmt_id->close();
    } else {
        header("Location: ../tempo-sono.php?error=true");
    }
}
$conn->close();
?>
