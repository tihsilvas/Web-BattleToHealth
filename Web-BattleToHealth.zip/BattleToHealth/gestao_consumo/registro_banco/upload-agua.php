<?php
session_start();

include "../../includes/conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["agua_litros"]) && !empty($_POST["agua_data"]) && !empty($_POST["agua_hora"])) {
        $litros = $_POST["agua_litros"];
        $data = $_POST["agua_data"];
        $hora = $_POST["agua_hora"];
        $email = $_SESSION['email'] ?? '';

        $sql_id = "SELECT id_usuario FROM tb_usuario WHERE email_usuario = ?";
        $stmt_id = $conn->prepare($sql_id);
        $stmt_id->bind_param("s", $email);
        $stmt_id->execute();
        $result_id = $stmt_id->get_result();

        if ($result_id->num_rows > 0) {
            $row_id = $result_id->fetch_assoc();
            $id_usuario = $row_id['id_usuario'];

            $sql_insert = "INSERT INTO tb_agua (id_usuario, qnt_agua, data_agua, hr_agua) VALUES (?, ?, ?, ?)";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bind_param("isss", $id_usuario, $litros, $data, $hora);

            if ($stmt_insert->execute()) {
                header("Location: ../consumo-agua.php?success=true");
                exit();
            } else {
                header("Location: ../consumo-agua.php?error=true");
            }
        } else {
            header("Location: ../consumo-agua.php?error=true");
        }
        $stmt_id->close();
    } else {
        header("Location: ../consumo-agua.php?error=true");
    }
}
$conn->close();
?>
