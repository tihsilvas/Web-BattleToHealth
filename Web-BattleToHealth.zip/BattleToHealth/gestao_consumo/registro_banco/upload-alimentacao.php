<?php
session_start();

include "../../includes/conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["alimentacao-tipo"]) && !empty($_POST["alimentacao-data"]) && !empty($_POST["alimentacao-hora"]) && !empty($_POST["alimentacao-caloria"])) {
        $tipo = $_POST["alimentacao-tipo"];
        $data = $_POST["alimentacao-data"];
        $hora = $_POST["alimentacao-hora"];
        $calorias = $_POST["alimentacao-caloria"];
        $email = $_SESSION['email'] ?? '';

        $sql_id = "SELECT id_usuario FROM tb_usuario WHERE email_usuario = ?";
        $stmt_id = $conn->prepare($sql_id);
        $stmt_id->bind_param("s", $email);
        $stmt_id->execute();
        $result_id = $stmt_id->get_result();

        if ($result_id->num_rows > 0) {
            $row_id = $result_id->fetch_assoc();
            $id_usuario = $row_id['id_usuario'];

            $sql_insert = "INSERT INTO tb_alimentacao (id_usuario, hr_alimentacao, tipo_alimentacao, calorias_alimentacao, data_alimentacao) VALUES (?, ?, ?, ?, ?)";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bind_param("issss", $id_usuario, $hora, $tipo, $calorias, $data);

            if ($stmt_insert->execute()) {
                header("Location: ../alimentacao.php?success=true");
                exit();
            } else {
                header("Location: ../alimentacao.php?error=true");
            }
        } else {
            header("Location: ../alimentacao.php?error=true");
        }
        $stmt_id->close();
    } else {
        header("Location: ../alimentacao.php?error=true");
    }
}
$conn->close();
?>
