<?php
require_once 'includes/conexao.php';
require_once 'criptografia/descriptografar.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["txt_senha"]) && !empty($_POST["txt_email"])) {
        $senha = $_POST["txt_senha"];
        $email = $_POST["txt_email"];

        // Consultar o banco de dados para obter o usuário com o email fornecido
        $query = "SELECT * FROM tb_usuario";
        $result = mysqli_query($conn, $query);

        if ($result) {
            while ($row = mysqli_fetch_assoc($result)) {
                $email_descriptografado = decryptData($row['email_usuario'], $key);
                if ($email === $email_descriptografado) {
                    $senha_descriptografada = decryptData($row['senha_usuario'], $key);

                    if ($senha === $senha_descriptografada) {
                        session_start();
                        $_SESSION['email'] = $row['email_usuario'];
                        $_SESSION['nome'] = $row['nome_usuario'];
                        $_SESSION['logado'] = true;
                        header('Location: index.php');
                        exit();
                    } else {
                        // Senha incorreta
                        session_start();
                        $_SESSION['erro_login'] = "Email ou Senha inválido. Tente novamente.";
                        header('Location: login.php');
                        exit();
                    }
                }
            }
            // Usuário não encontrado
            session_start();
            $_SESSION['erro_login'] = "Email ou Senha inválido. Tente novamente.";
            header('Location: login.php');
            exit();
        } else {
            // Erro na consulta SQL
            session_start();
            $_SESSION['erro_login'] = "Email ou Senha inválido. Tente novamente.";
            header('Location: login.php');
            exit();
        }
    }
}
?>
