<?php
    if (isset($_SESSION['campo_vazio'])) {
        echo "<script>alert('Campo não foi Preenchido.');</script>";
        unset($_SESSION['campo_vazio']);
    }

    if(isset($_SESSION['erro'])) {
        echo "<script>alert('".$_SESSION['erro']."');</script>";
        unset($_SESSION['erro']); 
    }
    /*imagem mudança*/
    date_default_timezone_set('America/Sao_Paulo');
    $horaAtual = date('H');
    $periodoDia = 'madrugada';
    if ($horaAtual >= 6 && $horaAtual < 12) {
        $periodoDia = 'manha';
    } elseif ($horaAtual >= 12 && $horaAtual < 18) {
        $periodoDia = 'tarde';
    } else {
        $periodoDia = 'noite';
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/formato.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="css/perfil.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" type="text/css" href="css/anima-surgi.css">
    <link rel="stylesheet" href="css/chat.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
    <title>Página de Perfil</title>
    <style>
        .cover-photo {
            flex: 1;
            background-image: url('img/<?php echo $periodoDia; ?>.gif');
        }
        .info-usuario li:not(.menu-health) {
            list-style-type: none;
            padding: 2.5vh 5vh;
            text-align: center;
            font-size: 2.2vh;
            transition: background-color 0.3s ease;
            cursor: pointer;
        }   
        .info-usuario li:not(.menu-health):hover {
            background-color: #f2f2f2;
        }
        .info-usuario li:last-child {
            border-top: 0.1vh solid #ccc;
            padding-top: 3vh;
        }
        .opcao-1 {
            border-top-left-radius: 25px; 
            border-top-right-radius: 25px;
        }
        .logout-link {
            text-decoration: none;
            color: #4285f4;
            font-weight: bold;
            transition: color 0.3s ease;
        }
        .logout-link:hover {
            color: #170fff;
        }
        .menu-health{
            user-select: none;
          
            background: linear-gradient(90deg, rgba(44,128,200,1) 35%, rgba(65,113,214,1) 100%);
            color: white;
            text-align: center;
            font-size: 2.3vh;
            font-weight: bold;
            padding: 3vh 5vh;

        }
    </style>
</head>
<body>
    <?php include_once("includes/header.php"); ?>
    <div class="container">
        <div class="cover-photo"></div>
        <form id="upload-form" action="upload.php" method="POST" enctype="multipart/form-data">
            <div class="foto_usuario" onclick="confirmChange()">
                <i class="fas fa-image icon"></i>
                <img src="<?php echo $foto_usuario; ?>" class="profile-pic anSurgimento" id="profile-pic">
            </div>
            <input type="file" id="foto_funcao" name="txt_foto" style="display: none;">
        </form>
        
        <div class="informacao_usuario">
            <div class="nome-container" onclick="abrirModal_nome()">
                <span ><?php echo !empty($nomeUsuario) ? substr($nomeUsuario, 0, 20) : "Nome Inválido";?>
                <i class="fas fa-pen edit-icon"></i></span>
            </div>
            
            <div class="bio-container" onclick="abrirModal_bio()">
                <span id="bioDisplay"><?php echo !empty($bio_usuario) ? nl2br($bio_usuario) : "Adicionar Bio"; ?></span>
                <i class="fas fa-pen edit-icon"></i>
            </div>
        </div>
    </div>
    
    <form id="modal_bio" class="modal anSurgimento" method="post" action="crud/upload-bio.php">
        <div class="modal-content">
            <span class="fechar" onclick="fecharModal_bio()">&times;</span>
            <img src="IMG/logo.jpg" alt="Logo">
            <p>Insira sua biografia no campo abaixo:</p>
            <textarea id="bioTextarea" class="bioInput" name="bio_text" rows="4" cols="50" maxlength="100"></textarea><br><br>
            <span id="bioCount"></span>
            <input type="submit" value="Enviar" class="botao-bio">
            
        </div>
    </form>
    
    <form id="modal_nome" class="modal anSurgimento" method="post" action="crud/upload-nome.php">
        <div class="modal-content">
            <span class="fechar" onclick="fecharModal_nome()">&times;</span>
            <img src="IMG/logo.jpg" alt="Logo">
            <p>Altere seu Nome no campo abaixo:</p>
            <input type="text" class="bioInput" name="nome_text" rows="4" cols="50" minlength="3" maxlength="20"></input><br><br>
            <span id="nomeCount"></span>
            <input type="submit" value="Enviar" class="botao-bio">
        </div>
    </form>
    
    <form id="modal_dados_sensiveis" class="modal anSurgimento" method="post" action="dados_sensiveis/verfica-senha.php">
        <div class="modal-content">
            <span class="fechar" onclick="fecharModal_dados_sensiveis()">&times;</span>
            <img src="IMG/logo.jpg" alt="Logo">
            <p>Digite sua Senha para Acessar as Informações Confidenciais:</p>
            <input type="password" class="bioInput" name="senha_atual_text" rows="4" cols="30" minlength="6" maxlength="30"></input><br><br>
            <span id="dadosCount"></span>
            <input type="submit" value="Enviar" class="botao-bio">
        </div>
    </form>
    
    <div class="info-usuario">
        <li class="menu-health opcao-1">GESTÃO HEALTH</li>
        <li class="info-usuario-item opcao-grafico" data-tabela="consumo-agua">Consumo de Água</li>
        <li class="info-usuario-item opcao-grafico" data-tabela="tempo-sono">Tempo de Sono</li>
        <li class="info-usuario-item opcao-grafico" data-tabela="alimentacao">Alimentação</li>
        <li class="info-usuario-item opcao-grafico" data-tabela="atividade-fisica">Atividade Física</li>
        <li onclick="abrirModal_dados_sensiveis()">Alterar Dados Sensíveis</li>
        <li class="logout-link" onclick="window.location.href='includes/logout.php';">Logout</li>
    </div>
    <div class="detalhes-usuario">
        <div class="chat-container">
            <div class="chat-header">
                <img src="img/logo.jpg" 
                style="width: 5%; float: left; border-radius: 25px; margin: 0vh 2vh 0vh 4vh" 
                alt="Battle to Health">
                <p style="margin-top: 2.4vh; font-size:2.5vh;">CHAT BOT</p>
            </div>
            <div class="chat-messages" id="chat-messages">
                <div class="message bot-message">Olá! Eu sou o ChatBot da Battle to Health. Para continuar nossa conversa, por favor, selecione uma das opções abaixo:</div>
            </div>
            <div class="chat-options">
                <button class="option-button" onclick="sendQuestion('Quais são os benefícios de uma boa noite de sono?')">Quais são os benefícios de uma boa noite de sono?</button>
                <button class="option-button" onclick="sendQuestion('Quais são algumas dicas para adormecer mais rapidamente à noite?')">Quais são algumas dicas para adormecer mais rapidamente à noite?</button>
                <button class="option-button" onclick="sendQuestion('Quais são os benefícios da água para a saúde?')">Quais são os benefícios da água para a saúde?</button>
                <button class="option-button" onclick="sendQuestion('Quais são os benefícios dos exercícios físicos?')">Quais são os benefícios dos exercícios físicos?</button>
                <button class="option-button" onclick="sendQuestion('Como posso melhorar minha alimentação?')">Como posso melhorar minha alimentação?</button>
                <button class="option-button" onclick="clearChat()">Limpar Chat</button>
            </div>
        </div>
    </div>
    <footer>
        <?php include_once("includes/footer.php");?>
    </footer>
    <script src="js/chat.js"></script>
    <script src="js/perfil.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="js/perfil-count.js"></script>
    <script>
        $(document).ready(function() {
            $('.info-usuario-item').click(function() {
                var tabela = $(this).data('tabela');
                window.location.href = 'gestao_consumo/' + tabela + '.php';
            });
        });
    </script>
        <?php if(isset($_SESSION['alerta'])): ?>
    <script>
        alert("<?php echo $_SESSION['alerta']; ?>");
    </script>
        <?php unset($_SESSION['alerta']); ?>
        <?php endif; ?>
</body>
</html>
