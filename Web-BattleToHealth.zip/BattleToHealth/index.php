<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" >
    <link rel="stylesheet" type="text/css" href="css/formato.css">
    <link rel="stylesheet" type="text/css" href="css/index.css">
    <link rel="stylesheet" type="text/css" href="css/anima-surgi.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
    <title>index</title>
</head>
<body>
    <header>
        <?php require_once("includes/header.php"); ?>
    </header>
    <main>
        <div class="index-container animacao-fundo">
            <div class="container-fundo-medico">
                <div class="boas-vindas-text anTransforma">Seja Bem vindo a<br> Battle to Health:<br>
                Cuidando para uma<br> Vida Melhor.</div>
                <div class="boas-vindas-text2 anTransforma">O Bem-estar perfeito<br>para você </div>
                <input type="button" class="botao-boas-vindas-text anTransforma" value="Saiba Mais" onclick="window.location.href = 'pag-sobre.php';"></input>
                <div class="circulo-branco"></div>
                <div class="circulo-branco"></div>
                <div class="circulo-branco"></div>
                <div class="circulo-branco margin-circulo-branco"></div>
            </div>
            <div class="boas-vindas-text-grande">
                <div class="container-medico">
                    <img src="img/medico.png" width="100%" height="80%"></img>
                </div>
            </div>
        </div>

        <div class="container-fundo-02">
        <h1>Battle to Health</h1>
        <div class="linha-index"></div>
        <div class="content">
            <p>
                Somos uma empresa comprometida em promover a saúde e o bem-estar através da nutrição e<br>
                cuidados com a qualidade de vida. Nossa missão é fornecer serviços e produtos que ajudem<br>
                nossos clientes a alcançar seus objetivos de saúde de forma sustentável e eficaz. Com uma<br>
                equipe de profissionais qualificados e apaixonados, estamos dedicados a oferecer orientação<br>
                personalizada, programas de alimentação balanceada e suporte contínuo para ajudar as<br>
                pessoas a viverem suas vidas da melhor maneira possível. Estamos aqui para ser o seu parceiro<br>
                na jornada rumo a uma vida mais saudável e feliz.
            </p>
            <input type="button" class="contato-index" value="Contate-nos" onclick="window.location.href = 'mailto:battletohealth@gmail.com';">
        </div>
        </div>

        <div class="index-container2">
        <div class="mobile-container">
            <div class="mobile-text1"><span class="check-icon">&#x2714;</span>Aprova-se</div>
            <div class="mobile-text2">Suas Metas<br> Alcançadas<br> com nosso APP</div>
            <input type="button" class="mobile-botao" value="Saiba mais" onclick="window.location.href = 'pag-mobile.php';"></input>
        </div>
        <div class="mobile-container mobile-container2">
            <img class="mobile-container-img" src="img/mobile-img.png"></img>
        </div>
    </div>
    </main>
    <footer>
        <?php include_once("includes/footer.php");?>
    </footer>
</body>
</html>
