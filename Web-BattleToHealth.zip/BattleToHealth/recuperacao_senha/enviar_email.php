<?php
require '../vendor/autoload.php';
require_once '../includes/conexao.php';
require_once '../criptografia/descriptografar.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Função para gerar código de verificação comf 6 caracteres
function generateVerificationCode() {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $code = '';
    $length = 6;
    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $code;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['txt_email'])) {
        $email = $_POST['txt_email'];

        include("../includes/conexao.php");

        $query = "SELECT * FROM tb_usuario";
        $result = mysqli_query($conn, $query);

        if ($result) {
            $email_econtrado = false;
            while ($row = mysqli_fetch_assoc($result)) {
                $email_descriptografado = decryptData($row['email_usuario'], $key);
                if ($email === $email_descriptografado) {
                    $email_econtrado = true;
                    break;
                }
            }
            if ($email_econtrado) {
                try {
                    $codigo_verificacao = generateVerificationCode();

                    $tempo_expiracao = time() + (3 * 60);

                    $mail = new PHPMailer(true);
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'tohealthbattle@gmail.com';
                    $mail->Password = 'fkoe ntlj lrhm pzbg';
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    $mail->CharSet = 'UTF-8';

                    $mail->setFrom('tohealthbattle@gmail.com', 'Battle to Health');
                    $mail->addAddress($email);

                    $mail->isHTML(true);
                    $mail->Subject = 'Código de Verificação';
                    $mail->Body = 'Seu código de verificação é: ' . $codigo_verificacao;

                    $mail->send();
                    $conn->close();

                    session_start();
                    $_SESSION['codigo_verificacao'] = $codigo_verificacao;
                    $_SESSION['tempo_expiracao'] = $tempo_expiracao;
                    $_SESSION['email'] = $email;

                    // Redirecionar para a página de inserção do código de verificação
                    header("Location: inserir_codigo.php");
                    exit();
                } catch (Exception $e) {
                    echo "Erro ao enviar e-mail: {$e->getMessage()}";
                }
            } else {
                echo '<script>alert("O email fornecido não está registrado!"); window.location.href = "../login.php";</script>';
            }
        }
    }
}
?>
