<?php
    session_start();

    if (isset($_SESSION['erro_login'])) {
        echo "<script>alert('{$_SESSION['erro_login']}');</script>";
        unset($_SESSION['erro_login']);
    }
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/formato.css">
    <link rel="stylesheet" type="text/css" href="css/login.css">
    <link rel="stylesheet" type="text/css" href="css/anima-surgi.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="css/voltar-icone.css">
    <title>Formulário de Login</title>
</head>
<body>
    <header></header>
    <a href="index.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
    <div class="form-panel anSurgimento"></div>
    <div class="form-container anSurgimento">
        <form method="post" action="validar.php" id="login-form">
            <div class="decide">
                <div class="escolha2">Logar</div>
                <div class="escolha"><a href="#" class="aescolha" id="sign-up-link">Cadastrar</a></div>
            </div>
            <p class="tituloform">Logar</p>
            <br>
            <br>
            <label for="email">Email:</label>
            <input type="email" class="campored aviso" name="txt_email" required>
          
            <label for="senha">Senha:</label>
            <input type="password" class="campored aviso" name="txt_senha" required>
            
            <input id="enviar" type="submit" name="login_submit" value="Logar-se">
            
            <div class="caixa_esq">
                <a class="esqsenha" href="recuperacao_senha/inserir_email.html">Esqueceu a Senha?</a>
            </div>
            <p class="erro">
                <?php if(isset($erro)) { echo $erro; } ?>
            </p>
        </form>
        <form method="post" action="processar.php" id="cadastro-form" style="display: none;" enctype="multipart/form-data">
            <div class="decide">
                <div class="escolha"><a href="#" class="aescolha" id="sign-in-link">Logar</a></div>
                <div class="escolha2">Cadastrar</div>
            </div>
            <p class="tituloform">Cadastrar</p>
            <br>
            <br>
            <label for="nome">Nome:</label>
            <input type="text" class="campocad aviso" name="txt_nome" required>
            <div class="avisotext">3 Caracteres no Mínimo</div>
            <label for="email">Email:</label>
            <input type="email" class="campocad aviso" name="txt_email" required>
            <div class="avisotext">Por Favor, Insira um Email Válido.</div>
          
            <label for="senha" class="avisolabel">Senha:</label>
            <input type="password" class="campocad aviso" name="txt_senha" required>
            <div class="avisotext">A Senha Precisa ser Forte(8 Caracteres)</div>

            <label for="senha">Confirmar Senha:</label>
            <input type="password" class="campocad aviso" name="txt_Rsenha" required>
            <div class="avisotext">As Senhas não Correspondem</div>

            <input id="enviar" type="submit" name="cadastro_submit" value="Cadastrar-se">
            
            <p class="erro">
                <?php if(isset($erro)) { echo $erro; } ?>
            </p>
        </form>
    </div>
    <script src="JS/verfiicacao.js"></script>
    <script src="JS/formulario.js"></script>
</body>
</html>
