<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Benefícios da Hidratação</title>
    <link rel="stylesheet" type="text/css" href="css/anima-surgi.css">
    <link rel="stylesheet" type="text/css" href="css/formato.css">
    <link rel="stylesheet" type="text/css" href="css/paginas-info.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
</head>
<body>
    <header>
        <?php include_once("includes/header.php"); ?>
    </header>
    <div class="container anSurgimento">
        <div class="logo-info">
            <img src="img/logo.jpg" alt="Battle to Health">
        </div>
        <h1>Benefícios da Hidratação</h1>
        <p class="p-titulo">Importância da Hidratação Adequada</p>
        <p>A hidratação adequada é fundamental para o bem-estar do corpo humano. A água desempenha papéis essenciais, como regulagem da temperatura, transporte de nutrientes, eliminação de toxinas e manutenção da saúde da pele, entre outros.</p>
        
        <p class="p-titulo">Fatores que Afetam a Hidratação</p>
        <p>Apesar dos diversos benefícios, muitas pessoas não consomem água suficiente diariamente. Isso pode ser atribuído a vários fatores, como hábitos inadequados, preferência por outras bebidas, falta de acesso à água potável e desconhecimento sobre os benefícios da hidratação adequada.</p>

        <p class="p-titulo">Benefícios para a Saúde</p>
        <p>Manter-se bem hidratado traz uma série de vantagens para a saúde, como melhora da função renal, auxílio na digestão, promoção da saúde da pele, aumento da energia, controle do peso, regulação da temperatura corporal, prevenção de cãibras musculares, melhora da concentração e redução do risco de pedras nos rins e infecções urinárias, entre outros.</p>

        <div class="representa-image">
            <img src="img/hidratacao.jpg">
            <p style="margin-bottom: -1%;  margin-top: 5%">Dr. Marcelo Pereira Silva</p>
            <p style="margin-bottom: -8%;">CRM-MG143251</p>
        </div>
    </div>
    <footer>
        <?php include_once("includes/footer.php"); ?>
    </footer>
</body>
</html>
