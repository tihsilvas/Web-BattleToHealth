<?php
session_start();
require_once '../includes/conexao.php';
require_once '../criptografia/descriptografar.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["senha_atual_text"])) {
        $senha_atual = $_POST["senha_atual_text"];

        // Consultar o banco de dados para obter o usuário com o email fornecido
        $query = "SELECT * FROM tb_usuario WHERE email_usuario = ?";
        $stmt = mysqli_prepare($conn, $query);
        mysqli_stmt_bind_param($stmt, "s", $_SESSION['email']);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);

        if ($row = mysqli_fetch_assoc($result)) {
            $senha_descriptografada = decryptData($row['senha_usuario'], $key);
            if ($senha_atual === $senha_descriptografada) {
                header('Location: dados-sensiveis.html');
                exit();
            } else {
                // Senha incorreta - definindo variável de sessão e redirecionando de volta para perfil.php
                $_SESSION['erro'] = "Senha incorreta. Tente novamente.";
                header('Location: ../perfil.php');
                exit();
            }
        } else {
            // Usuário não encontrado - definindo variável de sessão e redirecionando de volta para perfil.php
            $_SESSION['erro'] = "Usuário não encontrado.";
            header('Location: ../perfil.php');
            exit();
        }
    }
}
?>
