<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../css/formato.css">
    <link rel="stylesheet" href="../css/recuperar.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
    <title>Verificação de Código</title>
</head>
<body>
    <a href="alterar-email.html" class="back-icon"><i class="fas fa-arrow-left"></i></a>
    <div class="form-wrapper">
        <h2 class="titulo">Código de Verificação</h2>
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <label for="codigo">Informe o código de verificação:</label><br>
            <input type="text" id="codigo" name="codigo" required><br>
            <input type="submit" value="Verificar">
        </form>
    </div>
    <?php
    session_start();
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        if (isset($_SESSION['codigo_verificacao']) && isset($_SESSION['tempo_expiracao'])) {
            if ($_POST['codigo'] == $_SESSION['codigo_verificacao']) {
                $tempo_atual = time();
                // Verificar se o código não expirou
                if ($tempo_atual <= $_SESSION['tempo_expiracao']) {
                    $novo_email = $_SESSION['novo_email'];
                    header("Location: ../crud/upload-email.php?novo_email=$novo_email");
                    exit();
                } else {
                    echo "<p>O código de verificação expirou. Por favor, solicite outro código.</p>";
                }
            } else {
                echo "<p>Código de verificação incorreto. Tente novamente.</p>";
            }
        } else {
            echo "<p>Nenhum código de verificação foi enviado. Por favor, solicite um código primeiro.</p>";
        }
    }
    ?>
</body>
</html>
