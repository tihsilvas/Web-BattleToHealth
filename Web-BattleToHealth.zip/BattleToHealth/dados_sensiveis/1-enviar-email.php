<?php
session_start();
require '../vendor/autoload.php';
require_once '../includes/conexao.php';
require_once '../criptografia/descriptografar.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Função para gerar código de verificação com 6 caracteres
function generateVerificationCode() {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $code = '';
    $length = 6;
    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }
    return $code;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['novo_email'])) {
        $novo_email = $_POST['novo_email'];

        // Descriptografar e-mails do banco de dados para comparação
        $query = "SELECT email_usuario FROM tb_usuario";
        $result = mysqli_query($conn, $query);
        $emails = array();
        while ($row = mysqli_fetch_assoc($result)) {
            $email = decryptData($row['email_usuario'], $key);
            $emails[] = $email;
        }

        // Verificar se o novo e-mail já está cadastrado
        if (in_array($novo_email, $emails)) {
            echo '<script>alert("O endereço de e-mail já foi registrado. Favor escolher um diferente."); window.location.href = "alterar-email.html";</script>';
            exit();
        }

        // Se o e-mail não está cadastrado, prosseguir com o envio do código de verificação
        try {
            $codigo_verificacao = generateVerificationCode();
            $tempo_expiracao = time() + (3 * 60);

            $mail = new PHPMailer(true);
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'tohealthbattle@gmail.com';
            $mail->Password = 'fkoe ntlj lrhm pzbg';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            $mail->CharSet = 'UTF-8';

            $mail->setFrom('tohealthbattle@gmail.com', 'Battle to Health');
            $mail->addAddress($novo_email);

            $mail->isHTML(true);
            $mail->Subject = 'Código de Verificação';
            $mail->Body = 'Seu código de verificação é: ' . $codigo_verificacao;

            $mail->send();
            $_SESSION['codigo_verificacao'] = $codigo_verificacao;
            $_SESSION['tempo_expiracao'] = $tempo_expiracao;
            $_SESSION['novo_email'] = $novo_email;
            header("Location: 2-inserir-codigo.php");
            exit();
        } catch (Exception $e) {
            echo "Erro ao enviar e-mail: {$e->getMessage()}";
        }
    } else {
        echo '<script>alert("O e-mail não foi recebido"); window.location.href = "../dados_sensiveis/dados_sensiveis.html";</script>';
    }
}
?>
