<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="../css/perfil.css">
    <link rel="stylesheet" type="text/css" href="../css/anima-surgi.css">
    <link rel="stylesheet" type="text/css" href="../css/calculadora.css">
    <link rel="stylesheet" type="text/css" href="../css/formato.css">
    <link rel="stylesheet" type="text/css" href="../css/footer.css">
    <link rel="stylesheet" href="../css/voltar-icone.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="icon" href="../img/battle.ico" type="image/x-icon">
    <title>Dados Nutricionais</title>
</head>
<body>
    <div class="inicio">
        <a href="../index.php" class="back-icon"><i class="fas fa-arrow-left"></i></a>
        <h1>Dados Nutricionais</h1>
    </div>

    <div class="bio-container" onclick="abrirModal_tutorial()">
        <span id="bioDisplay" style="font-size: 2.3vh; font-weight: bold;">Como Funciona?</span>
        <i class="fas fa-tasks"></i>
    </div>
    <?php include_once("alimentos.php"); ?>

    <div id="cart">
        <h2><i class="fas fa-calculator"></i> Calculadora Alimentícia</h2>
        <hr>
        <div id="cartItems">
        </div>
        <div id="totalNutrients">
            Total de Nutrientes:
        </div>
        <br>
        <div id="totalCalories">
            Total de Calorias: 0
        </div>
    </div>

    <div id="modal_tutorial" class="modal anSurgimento">
        <div class="modal-content">
            <span class="fechar" onclick="fecharModal_tutorial()">&times;</span>
            <img src="../IMG/logo.jpg" alt="Logo">
            <p>Modo de Uso</p>
            <br>
            <div class="texto tutorial-content">
                <ul>
                    <li>Escolhendo Alimentos:
                        <ul>
                            Você clica nas imagens dos alimentos que deseja adicionar à lista. Por exemplo, se quiser adicionar frango à sua lista, clique na imagem do frango.
                    </li>
                </ul>
                </li>
                <br>
                <li>Lista de Compras:
                    <ul>
                        Cada vez que você clica em um alimento, ele é adicionado a uma lista especial no rodapé da página, lembrando cada alimento possui 100 gramas. É como colocar itens em uma cesta de compras.
                </li>
                </ul>
                </li>
                <br>
                <li>Contagem Automática:
                    <ul>
                        A calculadora automaticamente soma a quantidade de proteína, carboidratos e gordura de todos os alimentos que você selecionou. Ela também calcula o total de calorias com base nas informações nutricionais dos alimentos.
                </li>
                </ul>
                </li>
                <br>
                <li>Exibindo Totais:
                    <ul>
                        No final da lista, você vê quanto de proteína, carboidratos, gordura e calorias totais você selecionou até agora. É uma forma de entender o valor nutricional do que você está escolhendo.
                </li>
                </ul>
                </li>
                <br>
                <li>Removendo Alimentos:
                    <ul>
                        Se você mudar de ideia sobre um alimento, pode clicar em um botão para removê-lo da lista. Assim, os totais são atualizados automaticamente.
                </li>
                </ul>
                </li>
                <br>
                <li>Sempre Visível:
                    <ul>
                        A lista de compras fica sempre visível enquanto você navega pela página, para que você possa ver o que já escolheu a qualquer momento.
                </li>
                </ul>
                </li>
                </ul>
            </div>
        </div>
    </div>
    <footer> <?php include_once("../includes/footer.php");?></footer>
    <script src="../js/alimento.js"></script>
    <script src="../js/perfil.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
</body>
</html>