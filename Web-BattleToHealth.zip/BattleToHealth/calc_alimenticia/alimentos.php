<div id="container" class="anSurgimento">
    <div class="food" data-name="Carne Frango" data-weight="100" data-calories="237" data-protein="31"
        data-carbs="0" data-fat="3.6">
        <img src="../img/img-alimentos/frango.jpeg" alt="Frango">
        <div class="food-details">
            <h3>Frango</h3>
            <p class="food-nutrients">Proteína: 31g | Carboidratos: 0g <br> Gordura: 3.6g</p>
        </div>
    </div>
    <div class="food" data-name="Carne Vermelha" data-weight="100" data-calories="250" data-protein="26"
        data-carbs="0" data-fat="15">
        <img src="../img/img-alimentos/carne.jpeg" alt="Carne Vermelha">
        <div class="food-details">
            <h3>Carne Vermelha</h3>
            <p class="food-nutrients">Proteína: 26g | Carboidratos: 0g <br> Gordura: 15g</p>
        </div>
    </div>
    <div class="food" data-name="Arroz" data-weight="100" data-calories="130" data-protein="2.7" data-carbs="28"
        data-fat="0.3">
        <img src="../img/img-alimentos/arroz.jpeg" alt="Arroz">
        <div class="food-details">
            <h3>Arroz</h3>
            <p class="food-nutrients">Proteína: 2.7g | Carboidratos: 28g <br> Gordura: 0.3g</p>
        </div>
    </div>
    <div class="food" data-name="Macarrão" data-weight="100" data-calories="130" data-protein="5" data-carbs="25"
        data-fat="1">
        <img src="../img/img-alimentos/macarrao.jpg" alt="Macarrão">
        <div class="food-details">
            <h3>Macarrão</h3>
            <p class="food-nutrients">Proteína: 5g | Carboidratos: 25g <br> Gordura: 1g</p>
        </div>
    </div>
    <div class="food" data-name="Peixe" data-weight="100" data-calories="206" data-protein="20" data-carbs="0"
        data-fat="13">
        <img src="../img/img-alimentos/peixe.jpg" alt="Peixe">
        <div class="food-details">
            <h3>Peixe</h3>
            <p class="food-nutrients">Proteína: 20g | Carboidratos: 0g <br> Gordura: 13g</p>
        </div>
    </div>
    <div class="food" data-name="Ovos" data-weight="100" data-calories="155" data-protein="13" data-carbs="1.1"
        data-fat="11">
        <img src="../img/img-alimentos/ovos.jpeg" alt="Ovos">
        <div class="food-details">
            <h3>Ovos</h3>
            <p class="food-nutrients">Proteína: 13g | Carboidratos: 1.1g <br> Gordura: 11g</p>
        </div>
    </div>
    <div class="food" data-name="Feijão" data-weight="100" data-calories="347" data-protein="23" data-carbs="63"
        data-fat="1.5">
        <img src="../img/img-alimentos/feijao.jpg" alt="Feijão">
        <div class="food-details">
            <h3>Feijão</h3>
            <p class="food-nutrients">Proteína: 23g | Carboidratos: 63g <br> Gordura: 1.5g</p>
        </div>
    </div>
    <div class="food" data-name="Batata" data-weight="100" data-calories="77" data-protein="2" data-carbs="17"
        data-fat="0.1">
        <img src="../img/img-alimentos/batata.jpg" alt="Batata">
        <div class="food-details">
            <h3>Batata</h3>
            <p class="food-nutrients">Proteína: 2g | Carboidratos: 17g <br> Gordura: 0.1g</p>
        </div>
    </div>
    <div class="food" data-name="Cenoura" data-weight="100" data-calories="41" data-protein="0.9" data-carbs="10"
        data-fat="0.2">
        <img src="../img/img-alimentos/cenoura.jpeg" alt="Cenoura">
        <div class="food-details">
            <h3>Cenoura</h3>
            <p class="food-nutrients">Proteína: 0.9g | Carboidratos: 10g <br> Gordura: 0.2g</p>
        </div>
    </div>
    <div class="food" data-name="Brócolis" data-weight="100" data-calories="34" data-protein="2.8" data-carbs="7"
        data-fat="0.4">
        <img src="../img/img-alimentos/brocolis.jpeg" alt="Brócolis">
        <div class="food-details">
            <h3>Brócolis</h3>
            <p class="food-nutrients">Proteína: 2.8g | Carboidratos: 7g <br> Gordura: 0.4g</p>
        </div>
    </div>
    <div class="food" data-name="Espinafre" data-weight="100" data-calories="23" data-protein="2.9" data-carbs="3.6"
        data-fat="0.4">
        <img src="../img/img-alimentos/espinafre.jpg" alt="Espinafre">
        <div class="food-details">
            <h3>Espinafre</h3>
            <p class="food-nutrients">Proteína: 2.9g | Carboidratos: 3.6g <br> Gordura: 0.4g</p>
        </div>
    </div>
    <div class="food" data-name="Abóbora" data-weight="100" data-calories="26" data-protein="1" data-carbs="6.5"
        data-fat="0.1">
        <img src="../img/img-alimentos/abobora.jpeg" alt="Abóbora">
        <div class="food-details">
            <h3>Abóbora</h3>
            <p class="food-nutrients">Proteína: 1g | Carboidratos: 6.5g <br> Gordura: 0.1g</p>
        </div>
    </div>
</div>
