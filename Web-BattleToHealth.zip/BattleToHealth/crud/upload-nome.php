<?php
session_start();

include "../includes/conexao.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["nome_text"])) {
        $nome_text = $_POST["nome_text"];
        $email = $_SESSION['email'] ?? ''; // Obtém o email do usuário logado

        // Atualiza apenas o nome do usuário com o email correspondente
        $sql = "UPDATE tb_usuario SET nome_usuario = '$nome_text' WHERE email_usuario = '$email'";
        if ($conn->query($sql) === TRUE) {
            header("Location: ../perfil.php");
            exit();
        } else {
            echo "Erro ao atualizar o nome: " . $conn->error;
        }
    } else {
        $_SESSION['campo_vazio'] = true;
        header("Location: ../perfil.php");
        exit();
    }
}
$conn->close();
?>
