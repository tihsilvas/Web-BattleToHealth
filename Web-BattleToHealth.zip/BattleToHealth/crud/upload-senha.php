<?php
session_start();
include "../includes/conexao.php";
require_once '../criptografia/criptografar.php'; 

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (!empty($_POST["nova_senha"]) && !empty($_POST["confirmar_senha"])) {
        $nova_senha = $_POST["nova_senha"];
        $confirmar_senha = $_POST["confirmar_senha"];
        $email_logado = $_SESSION['email'] ?? ''; // Obtém o email do usuário logado

        if ($nova_senha === $confirmar_senha) {
            $senha_criptografada = encryptData($nova_senha, $key);

            // Atualiza apenas a senha do usuário logado
            $sql_senha = "UPDATE tb_usuario SET senha_usuario = '$senha_criptografada' WHERE email_usuario = '$email_logado'";
            if ($conn->query($sql_senha) === TRUE) {
                header("Location: sucesso-senha.html");
                exit();
            } else {
                echo "Erro ao atualizar a senha: " . $conn->error;
            }
        } else {
            echo "As senhas não coincidem.";
        }
    } else {
        header("Location: ../perfil.php");
        exit();
    }
}
$conn->close();
?>
