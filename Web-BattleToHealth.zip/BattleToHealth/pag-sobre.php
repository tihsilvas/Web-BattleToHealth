<!DOCTYPE html>
<html lang="pt-br">
  <head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="css/formato.css">
  <link rel="stylesheet" type="text/css" href="css/anima-surgi.css">
  <link rel="icon" href="img/battle.ico" type="image/x-icon">
  <title>Sobre a Battle to Health</title>
    <style>
      body {
          background-image: url('img/fundo1.jpg');
          background-size: cover;
          background-repeat: no-repeat;
          background-attachment: fixed; 
          font-family: Verdana, sans-serif;
      }

      main {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        color: #333;
        transition: background-color 0.3s ease;
        text-align: center;
        padding: 5vh;
        transition: opacity 0.5s ease;
        line-height: 1.6;
      }
      .sobre-container {
        max-width: 70%;
        margin: 0 auto;
        margin-top: 10vh;
        background-color: #ffffff;
        padding: 5vh;
        border-radius: 8px;
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        transition: box-shadow 0.3s ease;
        text-align: left;
      }
      #sobre-info h1 {
        color: #3079e7;
        margin-bottom: 2vh;
      }
      #sobre-info p:not(.sobre-subt) {
        color: #373737;
        margin-bottom: 1.5vh;
        line-height: 2;
      }
      #sobre-info ul {
        color: #3079e7;
        padding-left: 3.2vh;
        margin-bottom: 2vh;
        line-height: 2;
      }
      .sobre-subt{
        color: #3079e7;
      }
    </style>
  </head>
<body>
  <header>
    <?php require_once("includes/header.php"); ?>
  </header>
  <main>
    <div class="sobre-container anTransforma">
      <section id="sobre-info">
      <h1><i class="fas fa-info-circle"></i> Sobre a Battle to Health</h1>
        <p>A Battle to Health é uma empresa dedicada a promover qualidade de vida por meio de soluções inovadoras. Nosso objetivo é ajudar as pessoas a viverem vidas mais saudáveis e felizes.</p>
        <p>Nossos principais serviços incluem:</p>
        <ul>
        <p class="sobre-subt"><strong>Monitoramento do Consumo de Água:</strong></p><p>Desenvolvemos aplicativos intuitivos para ajudar os usuários a acompanhar e melhorar seu consumo diário de água.</li>
        <p class="sobre-subt"><strong>Calculadora Alimentícia:</strong></p><p>Oferecemos uma ferramenta poderosa para calcular e planejar dietas equilibradas, de acordo com as necessidades individuais de cada usuário.</li>
        <p class="sobre-subt"><strong>Tempo de Sono:</strong></p><p>Nosso aplicativo registra e analisa os padrões de sono dos usuários, fornecendo insights valiosos para melhorar a qualidade do sono.</li>
          <p>E muitos outros recursos e ferramentas para promover um estilo de vida saudável e equilibrado.</li>
        </ul>
        <p>Nossa missão é criar um impacto positivo na vida das pessoas, capacitando-as a fazer escolhas mais informadas e saudáveis em seu dia a dia.</p>
        <p>Trabalhamos constantemente para alcançar nossas metas de:</p>
        <ul>
          <p class="sobre-subt"><strong>Inovação:</strong></p><p> Desenvolver soluções tecnológicas inovadoras para melhorar a saúde e o bem-estar.</li>
          <p class="sobre-subt"><strong>Impacto:</strong></p><p> Criar um impacto significativo na qualidade de vida de nossos usuários.</li>
          <p class="sobre-subt"><strong>Satisfação do Cliente:</strong></p><p> Garantir a satisfação e o sucesso de nossos clientes em sua jornada de saúde.</li>
          <p class="sobre-subt"><strong>Sustentabilidade:</strong></p><p> Promover práticas sustentáveis e responsáveis em todas as nossas operações.</li>
        </ul>
        <p>Junte-se a nós na jornada para uma vida mais saudável e feliz!</p>
      </section>
    </div>
  </main>
  <footer>
    <?php include_once("includes/footer.php");?>
  </footer>
</body>
</html>
