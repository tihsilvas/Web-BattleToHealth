<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Benefícios da Atividade Física</title>
    <link rel="stylesheet" type="text/css" href="css/anima-surgi.css">
    <link rel="stylesheet" type="text/css" href="css/formato.css">
    <link rel="stylesheet" type="text/css" href="css/paginas-info.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
</head>
<body>
    <header>
        <?php include_once("includes/header.php"); ?>
    </header>
    <div class="container anSurgimento">
        <div class="logo-info">
            <img src="img/logo.jpg" alt="Battle to Health">
        </div>
        <h1>Benefícios da Atividade Física</h1>
        <p class="p-titulo">Importância da Atividade Física</p>
        <p>A atividade física regular é fundamental para a manutenção da saúde e do bem-estar. Ela não apenas fortalece os músculos e ossos, mas também melhora a função cardiovascular, aumenta a resistência, promove a saúde mental e ajuda na prevenção de diversas doenças crônicas.</p>
        
        <p class="p-titulo">Fatores que Influenciam a Atividade Física</p>
        <p>Diversos fatores podem influenciar a participação em atividades físicas, incluindo o estilo de vida, a disponibilidade de tempo, o acesso a instalações esportivas, o nível de motivação, o apoio social e os benefícios percebidos da atividade física.</p>

        <div class="representa-image">
            <img src="img/atividade-fisica.jpeg" alt="Atividade Física">
            <p>Mantenha-se ativo para colher todos esses benefícios!</p>
        </div>

        <!-- <p class="p-titulo">Benefícios para a Saúde</p> -->
        <p style="margin-bottom: -1%;">Dr. Felipe Carvalho Moreira</p>
        <p style="margin-bottom: -5%;">CRM-SP133556</p>
        </div>
    <footer>
        <?php include_once("includes/footer.php"); ?>
    </footer>
</body>
</html>
