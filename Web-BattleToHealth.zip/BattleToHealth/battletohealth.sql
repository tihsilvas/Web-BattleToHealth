CREATE DATABASE IF NOT EXISTS `battle`;
USE `battle`;

  CREATE TABLE `tb_usuario` (
    `email_usuario` VARCHAR(256) NOT NULL COMMENT 'Varchar 256 = Criptografia',
    `senha_usuario` VARCHAR(256) NOT NULL COMMENT 'Varchar 256 = Criptografia',
    `nome_usuario` VARCHAR(50) NOT NULL,
    `id_usuario` INT PRIMARY KEY NOT NULL AUTO_INCREMENT COMMENT 'Cada usuário terá seu id próprio gerado',
    `foto_usuario` VARCHAR(255) DEFAULT NULL COMMENT 'Null = Decisão do Usuário',
    `bio_usuario` VARCHAR(255) DEFAULT NULL COMMENT 'Null = Decisão do Usuário',
  );

CREATE TABLE `tb_agua` (
  `id_agua` INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `id_usuario` INT,
  `qnt_agua` DOUBLE NOT NULL COMMENT 'Em litros',
  `data_agua` DATE NOT NULL COMMENT 'Data do consumo',
  `hr_agua` TIME NOT NULL COMMENT 'Horário do consumo',
  FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario)
);

CREATE TABLE `tb_sono` (
  `id_sono` INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `id_usuario` INT,
  `temp_sono` DOUBLE NOT NULL COMMENT 'Tempo que o usuário dormiu',
  `data_sono` DATE NOT NULL COMMENT 'Data do usuario para dormir',
  `hr_sono` TIME NOT NULL COMMENT 'Horário que foi dormir',
  FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario)
);

CREATE TABLE `tb_atividade_fisica` (
  `id_atividade` INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `id_usuario` INT,
  `tipo_atividade` VARCHAR(50) NOT NULL,
  `data_atividade` DATE NOT NULL COMMENT 'Data que o usuario realizou tal alto',
  `temp_atividade` DOUBLE NOT NULL COMMENT 'Tempo que o usuário se exercitou',
  FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario)
);

CREATE TABLE `tb_alimentacao` (
  `id_alimentacao` INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
  `id_usuario` INT,
  `hr_alimentacao` TIME NOT NULL COMMENT 'Horário que foi se alimentar',
  `tipo_alimentacao` VARCHAR(50) NOT NULL COMMENT 'Tipo de alimento que o usuario consumiu',
  `calorias_alimentacao` DOUBLE(8,2) NOT NULL COMMENT 'Tipo de alimento que o usuario consumiu',
  `data_alimentacao` DATE NOT NULL COMMENT 'Data que o usuario realizou a refeicao',
  FOREIGN KEY (id_usuario) REFERENCES tb_usuario(id_usuario)
);

/* INCERTS REFERENTES A AULA 09/04/2024*/

INSERT INTO `tb_usuario` (`email_usuario`, `senha_usuario`, `nome_usuario`, `id_usuario`, `foto_usuario`) VALUES
('ce963baf292cb34903c0901d7271c8b7956a618e803bdaf7082288867f74f36c', '$2y$10$CA29HH3ISJCnGmDg9q/Nlu8aHh/cM7BYAtnx2QPoAnR3ob6Oro7By', 'João', 41, 'perfil/65f9ee1d24fc9_CÉLULA PROCARIONTE - 3 DS 4.pptx'),
('f9e4086a62baf4a4613e1c3f76f43e80e8c4a47278d15107510a240fbdbbee43', '$2y$10$0L/u3iHRGvBsguiwyshA2.Ufq2wR0GZacQoHr.fsKBX19TP8RRiwy', 'PiresGomes', 42, 'perfil/65f9eef895e2b_OIP (2).jpg');

INSERT INTO tb_agua (id_usuario, qnt_agua, data_agua, hr_agua) VALUES
(1, 1.5, '2024-04-07', '02:00:00'),
(1, 2.0, '2024-04-05', '10:30:00'),
(1, 1.7, '2024-04-03', '08:00:00'),
(1, 1.5, '2024-05-07', '07:00:00'),
(1, 2.0, '2024-05-05', '12:30:00'),
(1, 1.7, '2024-05-03', '02:00:00'),
(1, 2.5, '2024-07-08', '10:30:00');

INSERT INTO tb_sono (id_usuario, temp_sono, data_sono, hr_sono) VALUES
(41, 7.5, '2024-04-08', '23:00:00'),
(41, 8.0, '2024-04-08', '22:30:00'),
(42, 6.5, '2024-04-08', '10:00:00'),
(42, 2.0, '2024-04-08', '19:30:00');

INSERT INTO tb_atividade_fisica (id_usuario, tipo_atividade, data_atividade, temp_atividade) VALUES
(41, 'Corrida', '2024-04-08', 1.8),
(41, 'Caminhada', '2024-04-08', 1.2),
(42, 'Corrida', '2024-04-08', 1.1),
(42, 'Caminhada', '2024-04-08', 1.9);

INSERT INTO tb_alimentacao (id_usuario, hr_alimentacao, tipo_alimentacao, data_alimentacao) VALUES
(41, '10:30:00', 'Salada', '2024-04-08'),
(42, '13:00:00', 'Frango Grelhado', '2024-04-08'),
(42, '11:30:00', 'Salada', '2024-02-08'),
(42, '12:00:00', 'Frango Grelhado', '2024-05-08');