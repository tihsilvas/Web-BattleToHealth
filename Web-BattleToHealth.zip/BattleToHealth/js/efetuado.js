setTimeout(function () {
    window.location.href = 'login.php?status=success';
}, 5000);

