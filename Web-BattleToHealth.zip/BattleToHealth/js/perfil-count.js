$(document).ready(function() {
    $('#bioTextarea').on('input', function() {
        var charCount = $(this).val().length;
        $('#bioCount').text(charCount + '/100');

        if (charCount > 100) {
            $(this).val($(this).val().substring(0, 100));
            $('#bioCount').text('100/100');
        }
    });

    $('#modal_nome input[name="nome_text"]').on('input', function() {
        var nomeLength = $(this).val().length;
        $('#nomeCount').text(nomeLength + '/20');

        if (nomeLength < 3) {
            $('#nomeCount').css('color', 'red');
        } else {
            $('#nomeCount').css('color', 'inherit');
        }
    });

    $('#modal_dados_sensiveis input[name="nome_text"]').on('input', function() {
        var dadosLength = $(this).val().length;
        $('#dadosCount').text(dadosLength + '/30');

        if (dadosLength < 6) {
            $('#dadosCount').css('color', 'red');
        } else {
            $('#dadosCount').css('color', 'inherit');
        }
    });
});