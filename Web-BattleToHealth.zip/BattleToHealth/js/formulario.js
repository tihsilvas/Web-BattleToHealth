document.getElementById("sign-in-link").addEventListener("click", function(event){
    event.preventDefault();
    document.getElementById("cadastro-form").classList.remove("anima-entrada-form");
    document.getElementById("login-form").classList.add("anima-entrada-form");
    document.getElementById("login-form").style.display = "block";
    document.getElementById("cadastro-form").classList.add("anima-saida-form");
    document.getElementById("cadastro-form").style.display = "none";
});

document.getElementById("sign-up-link").addEventListener("click", function(event){
    event.preventDefault();
    document.getElementById("login-form").classList.remove("anima-entrada-form");
    document.getElementById("cadastro-form").classList.add("anima-entrada-form");
    document.getElementById("cadastro-form").style.display = "block";
    document.getElementById("login-form").classList.add("anima-saida-form");
    document.getElementById("login-form").style.display = "none";
});

document.getElementById("sign-in-link").addEventListener("click", function(event){
    event.preventDefault();
    document.getElementById("cadastro-form").classList.remove("anima-saida-form");
});

document.getElementById("sign-up-link").addEventListener("click", function(event){
    event.preventDefault();
    document.getElementById("login-form").classList.remove("anima-saida-form");
});
