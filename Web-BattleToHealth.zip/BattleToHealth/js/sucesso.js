function exibirAlertaSucesso() {
    var alerta = document.getElementById('alertaSucesso');
    alerta.style.display = 'block'; // Exibe o alerta
    setTimeout(function() {
        alerta.style.display = 'none'; // Oculta o alerta após 8 segundos
        removerParametrosUrl(); // Remove os parâmetros após ocultar o alerta
    }, 8000);
}

function exibirAlertaErro() {
    var alerta = document.getElementById('alertaErro');
    alerta.style.display = 'block'; // Exibe o alerta
    setTimeout(function() {
        alerta.style.display = 'none'; // Oculta o alerta após 8 segundos
        removerParametrosUrl(); // Remove os parâmetros após ocultar o alerta
    }, 8000);
}

// Verificar se os parâmetros de sucesso ou erro estão presentes na URL
const urlParams = new URLSearchParams(window.location.search);
const successParam = urlParams.get('success');
const errorParam = urlParams.get('error');

if (successParam === 'true') {
    exibirAlertaSucesso(); // Chama a função para exibir o alerta de sucesso
}

if (errorParam === 'true') {
    exibirAlertaErro(); // Chama a função para exibir o alerta de erro
}

// Função para remover os parâmetros da URL
function removerParametrosUrl() {
    const newUrl = window.location.pathname; // Obtém a URL sem parâmetros
    window.history.replaceState({}, document.title, newUrl); // Substitui a URL atual
}

// Remove os parâmetros imediatamente após a página ser carregada
window.addEventListener('load', function() {
    if (successParam === 'true' || errorParam === 'true') {
        removerParametrosUrl(); // Remove os parâmetros logo após carregar a página
    }
});
