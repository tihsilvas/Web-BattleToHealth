const campoNome = document.querySelector('#cadastro-form [name="txt_nome"]');
campoNome.addEventListener('input', validarNome);

const campoEmail = document.querySelector('#cadastro-form [name="txt_email"]');
campoEmail.addEventListener('input', validarEmail);

const campoSenha = document.querySelector('#cadastro-form [name="txt_senha"]');
campoSenha.addEventListener('input', validarSenha);

const campoConfirmaSenha = document.querySelector('#cadastro-form [name="txt_Rsenha"]');
campoConfirmaSenha.addEventListener('input', validarConfirmacaoSenha);

function validarNome() {
    const campo = campoNome;
    const aviso = campo.nextElementSibling;
    if (campo.value.length < 3) {
        campo.classList.add('campo-invalido');
        aviso.style.color = 'red';
    } else {
        if (campo.value.length > 20) {
            campo.value = campo.value.slice(0, 20);
        }
        campo.classList.remove('campo-invalido');
        aviso.style.color = 'white';
    }
}

function validarEmail() {
    const campo = campoEmail;
    const aviso = campo.nextElementSibling;
    if (!isValidEmail(campo.value)) {
        campo.classList.add('campo-invalido');
        aviso.style.color = 'red';
    } else {
        campo.classList.remove('campo-invalido');
        aviso.style.color = 'white';
    }
}

function validarSenha() {
    const campo = campoSenha;
    const aviso = campo.nextElementSibling;
    const senha = campo.value;
    
    // Expressões regulares para verificar se a senha atende aos critérios
    const temCaractereEspecial = /[!@#$%^&*(),.?":{}|<>]/.test(senha);
    const temMaiusculo = /[A-Z]/.test(senha);
    const temNumero = /[0-9]/.test(senha);

    // Verifica se a senha possui pelo menos 8 caracteres e atende aos critérios
    if (senha.length < 8 || !temCaractereEspecial || !temMaiusculo || !temNumero) {
        campo.classList.add('campo-invalido');
        aviso.style.color = 'red';
    } else {
        campo.classList.remove('campo-invalido');
        aviso.style.color = 'white';
    }

    // Verifica se o campo de confirmação de senha precisa ser validado novamente
    validarConfirmacaoSenha();
}

function validarConfirmacaoSenha() {
    const campo = campoConfirmaSenha;
    const aviso = campo.nextElementSibling;
    const senha = campoSenha.value;
    if (campo.value !== senha) {
        campo.classList.add('campo-invalido');
        aviso.style.color = 'red';
    } else {
        campo.classList.remove('campo-invalido');
        aviso.style.color = 'white';
    }
}

function isValidEmail(email) {
    // Aceita apenas emails do Gmail
    const emailRegex = /^[^\s@]+@gmail\.com$/i;
    return emailRegex.test(email);
}
