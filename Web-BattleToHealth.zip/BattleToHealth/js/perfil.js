function selectProfileImage() {
    document.getElementById('foto_funcao').click();
}

function confirmChange() {
    if (confirm('Deseja alterar a Imagem de Perfil?')) {
        selectProfileImage();
    }
}

function abrirModal_tutorial() {
    var modal = document.getElementById("modal_tutorial");
    modal.style.display = "block";
}

function fecharModal_tutorial() {
    var modal = document.getElementById("modal_tutorial");
    modal.style.display = "none";
}

function abrirModal_bio() {
    var modal = document.getElementById("modal_bio");
    modal.style.display = "block";
}

function fecharModal_bio() {
    var modal = document.getElementById("modal_bio");
    modal.style.display = "none";
}

function abrirModal_nome() {
    var modal = document.getElementById("modal_nome");
    modal.style.display = "block";
}

function fecharModal_nome() {
    var modal = document.getElementById("modal_nome");
    modal.style.display = "none";
}

function abrirModal_dados_sensiveis() {
    var modal = document.getElementById("modal_dados_sensiveis");
    modal.style.display = "block";
}

function fecharModal_dados_sensiveis() {
    var modal = document.getElementById("modal_dados_sensiveis");
    modal.style.display = "none";
}

document.getElementById('foto_funcao').addEventListener('change', function(event) {
    document.getElementById('upload-form').submit();
});