// Mensagem de boas-vindas
var welcomeMessage = '<div class="message bot-message anSurgimento"><p class="message-text">Olá! Eu sou o ChatBot da Battle to Health. Para continuar nossa conversa, por favor, selecione uma das opções abaixo:</p></div>';

// Função para limpar o chat
function clearChat() {
    var chatMessages = document.getElementById('chat-messages');
    chatMessages.innerHTML = '';
    chatMessages.innerHTML = welcomeMessage; 
}

// Função para enviar uma pergunta
function sendQuestion(question) {
    appendMessage('user', question);
    appendTypingIndicator();

    setTimeout(function() {
        var botResponse = getBotResponse(question);
        appendMessage('bot', botResponse);
        removeTypingIndicator(); 
    }, 1000);
}

// Função para adicionar a mensagem de digitação
function appendTypingIndicator() {
    var chatMessages = document.getElementById('chat-messages');
    var typingIndicator = document.createElement('div');
    typingIndicator.className = 'message bot-message typing-indicator anSurgimento';
    typingIndicator.innerHTML = '<p class="message-text typing-animation">Digitando...</p>';
    typingIndicator.style.clear = 'both'; 
    typingIndicator.style.display = 'block';
    typingIndicator.style.marginTop = '2vh'; 
    chatMessages.appendChild(typingIndicator);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// Função para remover a mensagem de digitação
function removeTypingIndicator() {
    var chatMessages = document.getElementById('chat-messages');
    var typingIndicator = chatMessages.querySelector('.typing-indicator');
    if (typingIndicator) {
        chatMessages.removeChild(typingIndicator);
    }
}

// Função para adicionar uma mensagem ao chat
function appendMessage(sender, message) {
    var chatMessages = document.getElementById('chat-messages');
    var messageDiv = document.createElement('div');
    messageDiv.className = 'message ' + sender + '-message anSurgimento';
    var messageText = document.createElement('p');
    messageText.className = 'message-text';
    messageText.textContent = message;
    messageDiv.appendChild(messageText);

    // Verifica se existe uma mensagem de digitação e move-a para baixo
    var typingIndicator = chatMessages.querySelector('.typing-indicator');
    if (typingIndicator) {
        typingIndicator.style.clear = 'both';
        typingIndicator.style.display = 'block';
        typingIndicator.style.marginTop = '2vh';
        chatMessages.appendChild(typingIndicator);
    }

    chatMessages.appendChild(messageDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

function getBotResponse(userInput) {
    switch(userInput) {
        case 'Quais são os benefícios de uma boa noite de sono?':
            return 'Uma boa noite de sono traz diversos benefícios para a saúde, incluindo melhora na concentração, memória, regulação do humor, fortalecimento do sistema imunológico e prevenção de doenças crônicas, como diabetes e doenças cardiovasculares.';
        case 'Quais são algumas dicas para adormecer mais rapidamente à noite?':
            return 'Para adormecer mais rapidamente, tente criar uma rotina relaxante antes de dormir. Isso pode incluir tomar um banho quente, ler um livro ou ouvir música suave. Evite estimulantes como cafeína e luzes brilhantes antes de dormir.';
        case 'Quais são os benefícios da água para a saúde?':
            return 'A água desempenha um papel vital em várias funções corporais, incluindo transporte de nutrientes, regulação da temperatura corporal e lubrificação das articulações. Beber água suficiente ajuda a manter a hidratação adequada e pode melhorar a saúde da pele, o funcionamento dos rins e a digestão.';
        case 'Quais são os benefícios dos exercícios físicos?':
            return 'Os exercícios físicos regulares trazem uma série de benefícios para a saúde, incluindo melhora da saúde cardiovascular, fortalecimento muscular, aumento da flexibilidade e resistência, controle do peso corporal, redução do estresse e melhora do humor. Além disso, a prática regular de exercícios pode reduzir o risco de desenvolver várias condições crônicas, como doenças cardíacas, diabetes e depressão.';
        case 'Como posso melhorar minha alimentação?':
            return 'Para melhorar sua alimentação, procure incluir uma variedade de alimentos saudáveis em sua dieta, como frutas, vegetais, grãos integrais, proteínas magras e gorduras saudáveis. Evite alimentos processados, ricos em açúcar e gorduras saturadas. Planeje suas refeições com antecedência e faça escolhas conscientes ao comer fora de casa.';
        default:
            return 'Desculpe, não entendi.';
    }
}