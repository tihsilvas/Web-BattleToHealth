const foods = document.querySelectorAll('.food');
const cart = document.getElementById('cart');
const cartItems = document.getElementById('cartItems');
const totalCalories = document.getElementById('totalCalories');
const totalNutrients = document.getElementById('totalNutrients');
let totalCaloriesValue = 0;
let totalProtein = 0;
let totalCarbs = 0;
let totalFat = 0;
const cartItemsMap = {};

foods.forEach(food => {
    food.addEventListener('click', () => {
        const name = food.dataset.name;
        const weight = 100; // Alteração para 100g
        const calories = parseInt(food.dataset.calories);
        const protein = parseFloat(food.dataset.protein);
        const carbs = parseFloat(food.dataset.carbs);
        const fat = parseFloat(food.dataset.fat);

        if (cartItemsMap[name]) {
            cartItemsMap[name].quantity++;
            cartItemsMap[name].weight += weight; // Adiciona o peso do alimento ao total
            cartItemsMap[name].element.textContent = `${name} x${cartItemsMap[name].quantity} (${cartItemsMap[name].weight}g) | Calorias: ${(calories * cartItemsMap[name].quantity).toFixed()} | Proteína: ${(protein * cartItemsMap[name].quantity).toFixed(1)}g | Carboidratos: ${(carbs * cartItemsMap[name].quantity).toFixed(1)}g | Gordura: ${(fat * cartItemsMap[name].quantity).toFixed(1)}g`;
        } else {
            const item = document.createElement('div');
            item.textContent = `${name} x1 (${weight}g) | Calorias: ${calories} | Proteína: ${protein.toFixed(1)}g | Carboidratos: ${carbs.toFixed(1)}g | Gordura: ${fat.toFixed(1)}g`;
            cartItems.appendChild(item);
            cartItemsMap[name] = {
                quantity: 1,
                weight: weight,
                element: item,
                calories: calories,
                protein: protein,
                carbs: carbs,
                fat: fat
            };

            item.addEventListener('click', () => {
                totalCaloriesValue -= cartItemsMap[name].calories;
                totalProtein -= cartItemsMap[name].protein;
                totalCarbs -= cartItemsMap[name].carbs;
                totalFat -= cartItemsMap[name].fat;

                cartItemsMap[name].quantity--;
                cartItemsMap[name].weight -= weight; // Subtrai o peso do alimento do total

                cartItemsMap[name].element.textContent = `${name} x${cartItemsMap[name].quantity} (${cartItemsMap[name].weight}g) | Calorias: ${(cartItemsMap[name].calories * cartItemsMap[name].quantity).toFixed()} | Proteína: ${(cartItemsMap[name].protein * cartItemsMap[name].quantity).toFixed(1)}g | Carboidratos: ${(cartItemsMap[name].carbs * cartItemsMap[name].quantity).toFixed(1)}g | Gordura: ${(cartItemsMap[name].fat * cartItemsMap[name].quantity).toFixed(1)}g`;

                if (cartItemsMap[name].quantity === 0) {
                    delete cartItemsMap[name];
                    item.remove();
                }

                totalCalories.textContent = `Total de Calorias: ${totalCaloriesValue.toFixed()}`;
                totalNutrients.textContent = `Total de Nutrientes: Proteína: ${totalProtein.toFixed(1)}g | Carboidratos: ${totalCarbs.toFixed(1)}g | Gordura: ${totalFat.toFixed(1)}g`;

                if (Object.keys(cartItemsMap).length === 0) {
                    updateCartVisibility(false);
                }
            });
        }

        totalCaloriesValue += calories;
        totalProtein += protein;
        totalCarbs += carbs;
        totalFat += fat;

        totalCalories.textContent = `Total de Calorias: ${totalCaloriesValue.toFixed()}`;
        totalNutrients.textContent = `Total de Nutrientes: Proteína: ${totalProtein.toFixed(1)}g | Carboidratos: ${totalCarbs.toFixed(1)}g | Gordura: ${totalFat.toFixed(1)}g`;

        updateCartVisibility(true);
    });
});

function updateCartVisibility(show) {
    if (show) {
        cart.classList.add('active');
    } else {
        cart.classList.remove('active');
    }
}
