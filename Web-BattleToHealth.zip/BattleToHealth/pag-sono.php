<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Controle de Sono</title>
    <link rel="stylesheet" type="text/css" href="css/anima-surgi.css">
    <link rel="stylesheet" type="text/css" href="css/formato.css">
    <link rel="stylesheet" type="text/css" href="css/paginas-info.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
</head>
<body>
    <header>
        <?php include_once("includes/header.php"); ?>
    </header>
    <div class="container anSurgimento">
        <div class="logo-info">
            <img src="img/logo.jpg" alt="Battle to Health">
        </div>
        <h1>Controle de Sono</h1>
        <p class="p-titulo">Importância do Sono Adequado</p>
        <p>O sono desempenha um papel crucial na saúde e no bem-estar geral. Ele é essencial para a recuperação física e mental, consolidação da memória, regulação do humor e manutenção de um sistema imunológico saudável, entre outros benefícios.</p>
        
        <p class="p-titulo">Fatores que Afetam o Sono</p>
        <p>Diversos fatores podem afetar a qualidade do sono, incluindo estresse, ansiedade, hábitos de sono irregulares, ambiente de sono inadequado, consumo de cafeína e outros estimulantes, uso excessivo de dispositivos eletrônicos antes de dormir, entre outros.</p>

        <p class="p-titulo">Práticas para Melhorar o Sono</p>
        <p>Para melhorar a qualidade do sono, é importante adotar hábitos saudáveis, como estabelecer uma rotina de sono regular, criar um ambiente propício para dormir, praticar relaxamento antes de dormir, limitar a exposição a dispositivos eletrônicos, evitar grandes refeições e estimulantes antes de dormir, entre outras práticas.</p>

        <div class="representa-image">
            <img src="img/sono.jpg">
            <p style="margin-bottom: -1%;  margin-top: 5%">Dra. Helena Preste Moreira</p>
            <p style="margin-bottom: -9%;">CRM-RJ237526</p>
        </div>
    </div>
    <footer>
        <?php include_once("includes/footer.php"); ?>
    </footer>
</body>
</html>
