<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Política de Segurança da Informação</title>
    <link rel="stylesheet" type="text/css" href="css/anima-surgi.css">
    <link rel="stylesheet" type="text/css" href="css/formato.css">
    <link rel="stylesheet" type="text/css" href="css/paginas-info.css">
    <link rel="icon" href="img/battle.ico" type="image/x-icon">
</head>
<body>
    <header>
        <?php include_once("includes/header.php"); ?>
    </header>
    <div class="container anSurgimento">
        <div class="logo-info">
            <img src="img/logo.jpg" alt="Battle to Health">
        </div>
        <h1>Termos e Política</h1>
        
        <p class="p-titulo">Introdução e Conceitos:</p>
        <p>Esta Política orienta o comportamento da empresa. Espera-se que as partes interessadas definam seus direcionamentos a partir dessas orientações, considerando
        as necessidades específicas e os aspectos legais e regulamentares a que estão sujeitas.
        </p>
        
        <p class="p-titulo">Regulamentação:</p>
        <p>Esta política está em conformidade com todas as leis e regulamentos aplicáveis, incluindo o Decreto 9.637/2018 e as Resoluções 4.557/2017 e 4.893/2021 do
        Conselho Monetário Nacional, bem como a Resolução 85/21 do Banco Central do Brasil.
        </p>
        
        <p class="p-titulo">Periodicidade de Revisão:</p>
        <p>Esta política será revisada no mínimo anualmente, ou extraordinariamente, a qualquer momento,
        para garantir sua eficácia contínua.
        </p>
        
        <p class="p-titulo">Objetivo:</p>
        <p>O objetivo desta política é estabelecer diretrizes para a gestão da segurança da informação e cibernética, demonstrando o compromisso da 
        Battle to Health com a proteção das informações corporativas e demais ativos de informação.
        </p>

        <div class="politica-code">
            <img src="img/qr-seguranca.png" alt="QR Code">
        </div>
        <div class="politica-assinatura">
            <!-- <p>Assinatura: Edson de Souza Santos</p> -->
        </div>
    </div>
    <footer>
        <?php include_once("includes/footer.php"); ?>
    </footer>
</body>
</html>
